#!/usr/bin/env python3
"""Loopback-only single-engineer RAMS study application. Portable unified engineering views; no external layout process."""
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import platform
from pathlib import Path
import zipfile
from urllib.parse import urlparse, parse_qs
from rams import VERSION
from rams.engine import PRODUCER as RBD_PRODUCER
from rams.fault_tree import PRODUCER as FTA_PRODUCER
from rams.diagrams import bowtie, fault_tree, rbd, projection
from rams.engine import Invalid, canonical
from rams.repository import Repository, Conflict, KINDS, STATES, RELATIONS, coverage, requirement_coverage, preview_import, csv_register, sysml_projection
from rams.technical_review import review, traceability, related_records
from rams.insights import importance

ROOT = Path(__file__).resolve().parent


def bundle(archive):
    snapshot = archive['snapshot']
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as z:
        from rams.study_output import portable_html
        z.writestr('study.html', portable_html(archive))
        z.writestr('project.json', canonical(snapshot))
        z.writestr('history.json', canonical(archive['history']))
        z.writestr('README.txt', 'Local study export. project.json reopens as a new project. History, baselines and runs remain historical files; importing project.json does not restore their database identities. Not a signed approval record.\n')
        projection = sysml_projection(snapshot)
        z.writestr('model.sysml', projection['sysml'])
        z.writestr('projection.json', canonical(projection['projection']))
        z.writestr('register.csv', csv_register(snapshot))
        from rams.diagrams import bowtie, fault_tree, rbd, projection
        diagram_index = []
        for e in snapshot['entities']:
            if e['state'] == 'archived' or e['kind'] not in ('hazard', 'fault_gate'): continue
            method = 'bowtie' if e['kind'] == 'hazard' else 'fta'
            try:
                drawing = bowtie(snapshot, e['id'])[0] if method == 'bowtie' else fault_tree(snapshot, e['id'])
                path = f"diagrams/{method}-{e['id']}.svg"
                z.writestr(path, drawing)
                source_path = path[:-4] + '.json'
                z.writestr(source_path, canonical(projection(snapshot, 'fta' if method == 'fta' else 'bowtie', e['id'])))
                diagram_index.append({'source': source_path, 'method': method, 'record': e['id'], 'file': path, 'scope': 'Qualitative graphical view; not a calculated or approved result'})
            except Invalid as error:
                diagram_index.append({'method': method, 'record': e['id'], 'blocked': str(error)})
        for run_record in archive['runs']:
            run = run_record['body']
            if run.get('method') == 'static_fta': continue
            try:
                drawing = rbd(run['snapshot'], run['basis']['config']['tree'])
                path = f"diagrams/rbd-{run['id']}.svg"
                z.writestr(path, drawing)
                source_path = path[:-4] + '.json'
                z.writestr(source_path, canonical(projection(run['snapshot'], 'rbd', tree=run['basis']['config']['tree'])))
                diagram_index.append({'source': source_path, 'method': 'rbd', 'run': run['id'], 'file': path, 'scope': 'Exact retained run topology; probabilities remain in run JSON'})
            except (Invalid, KeyError) as error:
                diagram_index.append({'method': 'rbd', 'run': run.get('id'), 'blocked': str(error)})
        z.writestr('diagrams/index.json', canonical(diagram_index))
        for kind in ('runs', 'baselines'):
            for r in archive[kind]:
                z.writestr(f'{kind}/{r["id"]}.json', canonical(r['body']))
    return stream.getvalue()


def handler(repo):
    files = [ROOT/'server.py'] + [p for folder in ('rams','web','vendor/unified_visuals') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.js','.css','.html','.svg','.json')]
    build = hashlib.sha256()
    for path in sorted(files):
        build.update(str(path.relative_to(ROOT)).encode() + b'\0' + path.read_bytes() + b'\0')
    build_id = build.hexdigest()
    class Handler(BaseHTTPRequestHandler):
        server_version = 'RAMSWorkbench/' + VERSION

        def log_message(self, fmt, *args):
            pass

        def reply(self, value, status=200, content_type='application/json; charset=utf-8', filename=None):
            body = value if isinstance(value, bytes) else (value.encode() if isinstance(value, str) else canonical(value).encode())
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if filename: self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
            self.end_headers()
            self.wfile.write(body)

        def host_ok(self):
            port = self.server.server_port
            return self.headers.get('Host') in (f'127.0.0.1:{port}', f'localhost:{port}')

        def do_GET(self):
            try:
                if not self.host_ok(): return self.reply({'error': 'Loopback host required'}, 403)
                u = urlparse(self.path)
                if u.path in ('/', '/app.js', '/workflow-model.js', '/style.css'):
                    path = ROOT / 'web' / ('index.html' if u.path == '/' else u.path[1:])
                    content_type = {'/': 'text/html', '/app.js': 'text/javascript', '/workflow-model.js': 'text/javascript', '/style.css': 'text/css'}[u.path] + '; charset=utf-8'
                    return self.reply(path.read_bytes(), content_type=content_type)
                if u.path in ('/unified/engineering-view.js', '/unified/engineering-view.css'):
                    asset = ROOT / 'vendor/unified_visuals' / u.path.rsplit('/', 1)[1]
                    return self.reply(asset.read_bytes(), content_type=('text/javascript' if u.path.endswith('.js') else 'text/css') + '; charset=utf-8')
                if u.path in ('/icons/warning.svg', '/icons/table.svg', '/icons/chart-line.svg', '/icons/database.svg', '/icons/stack.svg', '/icons/gear.svg'):
                    return self.reply((ROOT / 'web' / u.path[1:]).read_bytes(), content_type='image/svg+xml')
                q = parse_qs(u.query)
                project = q.get('project', [''])[0]
                if u.path == '/api/health':
                    return self.reply({'status':'ok', 'version':VERSION, 'capability_revision':'professional-workflows/1', 'build':build_id, 'python':platform.python_version(), 'application_path':str(ROOT), 'database_path':str(Path(repo.path).resolve()), 'projects':len(repo.projects()), 'deployment':'Local single-engineer workspace; loopback only'})
                if u.path == '/api/info': return self.reply({'version': VERSION, 'kinds': KINDS, 'states': STATES, 'relations': list(RELATIONS), 'producers': {'rbd': RBD_PRODUCER, 'fta': FTA_PRODUCER}})
                if u.path == '/api/workspace-backup':
                    from rams.storage import snapshot_bytes
                    return self.reply(snapshot_bytes(repo.path), content_type='application/vnd.sqlite3', filename='rams-workspace.sqlite3')
                if u.path == '/api/projects': return self.reply(repo.projects())
                if u.path == '/api/technical-review': return self.reply(review(repo.get(project)))
                if u.path == '/api/traceability': return self.reply(traceability(repo.get(project)))
                if u.path == '/api/related-records': return self.reply(related_records(repo.get(project), q.get('record', [''])[0]))
                if u.path == '/api/importance': return self.reply(importance(repo.record(project, 'runs', q.get('run', [''])[0])))
                if u.path == '/api/project':
                    snap = repo.get(project)
                    return self.reply({**snap, 'coverage': coverage(snap), 'requirement_coverage': requirement_coverage(snap)})
                if u.path == '/api/diagram':
                    snap = repo.get(project)
                    kind = q.get('kind', [''])[0]
                    record = q.get('record', [''])[0]
                    if kind == 'bowtie': diagram = bowtie(snap, record)[0]
                    elif kind == 'fta': diagram = fault_tree(snap, record)
                    else: raise Invalid('Unknown engineering diagram kind')
                    return self.reply({'svg': diagram})
                if u.path == '/api/records': return self.reply(repo.records(project))
                if u.path == '/api/record': return self.reply(repo.record(project, q.get('kind', [''])[0], q.get('id', [''])[0]))
                if u.path == '/api/run-diagram':
                    run = repo.record(project, 'runs', q.get('run', [''])[0])
                    return self.reply({'svg': rbd(run['snapshot'], run['basis']['config']['tree'])})
                if u.path == '/api/study-html':
                    from rams.study_output import portable_html
                    return self.reply(portable_html(repo.archive(project)), content_type='text/html; charset=utf-8', filename='study.html')
                if u.path == '/api/export':
                    return self.reply(bundle(repo.archive(project)), content_type='application/zip', filename='rams-study.zip')
                if u.path == '/api/method-example': return self.reply((ROOT / 'examples' / 'analysis-methods.json').read_bytes())
                if u.path == '/api/example':
                    return self.reply((ROOT / 'examples' / 'synthetic-station.json').read_bytes())
                return self.reply({'error': 'Not found'}, 404)
            except Invalid as e:
                self.reply({'error': str(e)}, 400)
            except (ValueError, TypeError, KeyError, RecursionError) as e:
                self.reply({'error': 'Malformed request: ' + str(e)}, 400)

        def do_POST(self):
            try:
                if not self.host_ok() or self.headers.get('X-RAMS-Request') != '1':
                    return self.reply({'error': 'Same-origin app request required'}, 403)
                origin = self.headers.get('Origin')
                if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'):
                    return self.reply({'error': 'Cross-origin requests are disabled'}, 403)
                n = int(self.headers.get('Content-Length', '0'))
                if not 0 < n <= 20_000_000: raise Invalid('Request must be 1 byte to 20 MB')
                def invalid_constant(s): raise Invalid('Nonfinite JSON number: '+s)
                data = json.loads(self.rfile.read(n), parse_constant=invalid_constant)
                if not isinstance(data, dict): raise Invalid('JSON object required')
                route = urlparse(self.path).path
                if route == '/api/import-preview': return self.reply(preview_import(data.get('snapshot')))
                if route == '/api/complete-example':
                    from rams.examples import complete_study
                    return self.reply(complete_study(repo), 201)
                if route == '/api/create': return self.reply(repo.create(data.get('title'), data.get('snapshot')), 201)
                if route == '/api/mutate': return self.reply(repo.mutate(data.get('project'), data.get('expected'), data.get('operation')))
                if route == '/api/baseline': return self.reply(repo.baseline(data.get('project'), data.get('expected'), data.get('label')), 201)
                if route == '/api/rbd-diagram':
                    snap = repo.get(data.get('project'))
                    if snap['project']['revision'] != data.get('expected'): raise Conflict('RBD drawing basis is stale')
                    return self.reply({'svg': rbd(snap, data.get('tree')), 'revision': snap['project']['revision']})
                if route == '/api/fault-tree': return self.reply(repo.analyze_fault_tree(data.get('project'), data.get('expected'), data.get('config')), 201)
                if route == '/api/analyze': return self.reply(repo.analyze(data.get('project'), data.get('expected'), data.get('config')), 201)
                return self.reply({'error': 'Not found'}, 404)
            except Conflict as e:
                self.reply({'error': str(e)}, 409)
            except (Invalid, ValueError, TypeError, KeyError, RecursionError) as e:
                self.reply({'error': str(e)}, 400)
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5186)
    parser.add_argument('--database', type=Path, default=ROOT / '.local' / 'studies.sqlite3')
    args = parser.parse_args()
    repo = Repository(args.database)
    server = ThreadingHTTPServer(('127.0.0.1', args.port), handler(repo))
    print(f'RAMS Workbench {VERSION} at http://127.0.0.1:{server.server_port} — database: {args.database}', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__ == '__main__': main()
