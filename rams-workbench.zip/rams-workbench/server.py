#!/usr/bin/env python3
"""Loopback-only single-engineer RAMS study application. Portable unified engineering views; no external layout process."""
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import platform
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from rams import VERSION
from rams.engine import Invalid, canonical
from rams.repository import Repository, Conflict
from rams.service import bundle, dispatch

ROOT = Path(__file__).resolve().parent


def handler(repo):
    files = [ROOT/'server.py'] + [p for folder in ('rams','web','vendor/unified_visuals') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.js','.mjs','.css','.html','.svg','.json')]
    build = hashlib.sha256()
    for path in sorted(files):
        build.update(str(path.relative_to(ROOT)).encode() + b'\0' + path.read_bytes() + b'\0')
    build_id = build.hexdigest()
    class Handler(BaseHTTPRequestHandler):
        server_version = 'RAMSWorkbench/' + VERSION

        def log_message(self, fmt, *args):
            pass

        def reply(self, value, status=200, content_type='application/json; charset=utf-8', filename=None):
            body = value if isinstance(value, bytes) else (value.encode() if isinstance(value, str) else canonical(value).encode())
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if filename: self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
            self.end_headers()
            self.wfile.write(body)

        def host_ok(self):
            port = self.server.server_port
            return self.headers.get('Host') in (f'127.0.0.1:{port}', f'localhost:{port}')

        def do_GET(self):
            try:
                if not self.host_ok(): return self.reply({'error': 'Loopback host required'}, 403)
                u = urlparse(self.path)
                if u.path in ('/', '/app.js', '/workflow-model.js', '/transport.js', '/browser-client.js', '/browser-store.mjs', '/style.css'):
                    path = ROOT / 'web' / ('index.html' if u.path == '/' else u.path[1:])
                    content_type = {'/': 'text/html', '/app.js': 'text/javascript', '/workflow-model.js': 'text/javascript', '/transport.js':'text/javascript', '/browser-client.js':'text/javascript', '/browser-store.mjs':'text/javascript', '/style.css': 'text/css'}[u.path] + '; charset=utf-8'
                    return self.reply(path.read_bytes(), content_type=content_type)
                if u.path in ('/unified/engineering-view.js', '/unified/engineering-view.css'):
                    asset = ROOT / 'vendor/unified_visuals' / u.path.rsplit('/', 1)[1]
                    return self.reply(asset.read_bytes(), content_type=('text/javascript' if u.path.endswith('.js') else 'text/css') + '; charset=utf-8')
                if u.path in ('/icons/warning.svg', '/icons/table.svg', '/icons/chart-line.svg', '/icons/database.svg', '/icons/stack.svg', '/icons/gear.svg'):
                    return self.reply((ROOT / 'web' / u.path[1:]).read_bytes(), content_type='image/svg+xml')
                result=dispatch(repo,'GET',u.path,parse_qs(u.query),health={'capability_revision':'professional-workflows/1','build':build_id,'python':platform.python_version(),'application_path':str(ROOT),'database_path':str(Path(repo.path).resolve()),'deployment':'Local single-engineer workspace; loopback only'})
                return self.reply(result.value,result.status,result.content_type,result.filename)
            except Invalid as e:
                self.reply({'error': str(e)}, 400)
            except (ValueError, TypeError, KeyError, RecursionError) as e:
                self.reply({'error': 'Malformed request: ' + str(e)}, 400)

        def do_POST(self):
            try:
                if not self.host_ok() or self.headers.get('X-RAMS-Request') != '1':
                    return self.reply({'error': 'Same-origin app request required'}, 403)
                origin = self.headers.get('Origin')
                if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'):
                    return self.reply({'error': 'Cross-origin requests are disabled'}, 403)
                n = int(self.headers.get('Content-Length', '0'))
                if not 0 < n <= 20_000_000: raise Invalid('Request must be 1 byte to 20 MB')
                def invalid_constant(s): raise Invalid('Nonfinite JSON number: '+s)
                data = json.loads(self.rfile.read(n), parse_constant=invalid_constant)
                if not isinstance(data, dict): raise Invalid('JSON object required')
                result=dispatch(repo,'POST',urlparse(self.path).path,data=data)
                return self.reply(result.value,result.status,result.content_type,result.filename)
            except Conflict as e:
                self.reply({'error': str(e)}, 409)
            except (Invalid, ValueError, TypeError, KeyError, RecursionError) as e:
                self.reply({'error': str(e)}, 400)
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5186)
    parser.add_argument('--database', type=Path, default=ROOT / '.local' / 'studies.sqlite3')
    args = parser.parse_args()
    repo = Repository(args.database)
    server = ThreadingHTTPServer(('127.0.0.1', args.port), handler(repo))
    print(f'RAMS Workbench {VERSION} at http://127.0.0.1:{server.server_port} — database: {args.database}', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__ == '__main__': main()
