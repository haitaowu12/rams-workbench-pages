RAMS Workbench 0.4.0

Requires Python 3.11 or newer. No package installation or account is required.
Open a terminal in this extracted folder and run: python3 server.py
Then open http://127.0.0.1:5186/
On macOS, run.command provides the same launch.

Project menu > Example studies > Complete station study creates the fictional worked study.
Read the user guide and narrated walkthrough at http://127.0.0.1:5186/guide/
Your studies stay in .local/studies.sqlite3. Keep workspace backups separately.
This is a single-user study candidate; engineering qualification and approval remain open.
