# Method coverage and engineering outputs

FMECA retains function, causes and local/next/end effects; HAZOP retains finding/no-issue/deferred/not-applicable examinations. Technical review and trace/change views inspect the recorded study. Both retained RBD and quantified static FTA support replay-checked Birnbaum importance, perfect/failed input interventions and one-at-a-time ×0.5/×2 input scenarios. These scenarios are deterministic sensitivity cases, not uncertainty bounds or operational-availability analysis.


| Method | Working capability | Graphical / document output | Boundary |
|---|---|---|---|
| Preliminary / system hazard analysis | Hazard register, initial/residual categorical assessment, scope, owner and recorded decision | Hazard register CSV, JSON study, risk matrix and hazard inspector | No invented default policy or numerical arithmetic on risk categories |
| HAZOP | Nodes, intent, modes, participants, guide words, deviations, causes, consequences, safeguards and recommendations | Worksheet and full register CSV/JSON; typed paths feed hazard and bow-tie views | Workshop completeness and findings require human facilitation |
| FMEA / FMECA | Failure-mode, local/system effect, detection, response, severity and criticality notes | Worksheet, CSV/JSON, linked source records | No quantitative criticality or prediction handbook calculation is inferred from notes |
| Bow tie | Hazard-centred causal view with explicit preventive and mitigative allocations | Interactive diagram, portable SVG and study-bundle diagram index | Qualitative declarations only; no automatic barrier efficacy, risk reduction or LOPA arithmetic |
| Static FTA | AND/OR DAG, shared basic-event identity, absorption and minimal cut sets; optional independent-event quantification at an exact mode/horizon | Interactive diagram, SVG, minimal cut sets CSV, retained run JSON and replay | At most 16 distinct events, 256 reachable analysis nodes, depth 24, 10,000 intermediate cut-set candidates; drawing bound 80 nodes. No NOT, dynamic gates, conditional dependencies or CCF solver |
| RBD / reliability | Nested series and active parallel success logic on distinct physical items | Structured builder, RBD schematic SVG, retained curves / intermediate results and JSON replay | Existing independent exponential component boundary; no equivalent network MTBF |
| Availability / maintainability | Separate steady-state inherent A/U; component active-repair CDF | Separate results, run JSON and exact values | No operational availability, logistics, standby or shared repair crews |
| Assurance / requirements | Controls, implementing requirements, explicit per-mode/configuration obligations, verification declarations, retained small evidence files and SRAC/action records | Trace inspector, history, baseline delta, CSV/JSON and bounded SysML projection | Not authenticated approval, evidence adequacy or safety acceptance |

## Bow-tie meaning

`cause → causes → hazard → causes → consequence` is the declared causal structure. `control → controls → hazard` records hazard-level coverage. `control → prevents → cause` allocates a preventive barrier to the cause-to-top-event path; it does not assert that the initiating cause itself cannot occur. `control → mitigates → consequence` allocates a mitigative barrier to the top-event-to-consequence path. Allocation needs a rationale. Unallocated hazard controls remain visible rather than being positioned on an invented path. Barriers remain proposed or otherwise self-declared, with efficacy and escalation-factor review unresolved unless evidenced separately.

Dashed allocation lines are distinct from causal lines. The drawing is a qualitative allocation view, not a probability network. It does not aggregate controls as independent success blocks. The graphical view admits 30 causes/consequences and five allocated controls per path; larger studies must narrow the viewpoint, retaining all records in JSON.

## Fault-tree meaning

`event/gate → input_to → gate` is Boolean failure logic. A basic-event ID represents one event even when it is referenced by several gates. AND forms intersections; OR forms unions. Qualitative cut-set reduction removes duplicate and absorbed supersets. Optional quantification enumerates disjoint truth assignments of declared independent basic events, avoiding an independence assumption between cut sets or intermediate gates sharing an event.

Inputs are probabilities in [0,1] at an explicit horizon in hours and an exact operating mode. They are not failure rates. Every quantified event needs a source, conditions, horizon, mode and explicit independent-event review disposition/rationale. Declared dependencies, unsupported dynamic/common-cause input fields, missing data and mismatched modes/horizons block quantification. A represented shared cause can be one basic event in several paths; this does not prove that all remaining basic events are independent.

The synthetic example `(SHARED AND A) OR (SHARED AND B)` has independent probabilities 0.1, 0.2 and 0.3. Its cut sets are `{SHARED,A}` and `{SHARED,B}`; its exact Boolean top-event probability is `0.1 × (0.2 + 0.3 − 0.2 × 0.3) = 0.044`. Summing 0.02 and 0.03 would double count their overlap. These are invented demonstration probabilities, unrelated to the exponential RAM fixture.

Frozen FTA runs retain their complete study snapshot, inputs, logic links, configuration, producer identity, cut sets and probability (or explicit qualitative-only state). Same-producer replay is supported. Binary64 tail effects remain a stated warning; if a mathematically positive top-event probability collapses to zero, quantification is refused and no zero result is retained. Replay and cut-set agreement do not establish engineering completeness, model validation or acceptance.

## Outputs and exchange

Study ZIPs include the complete JSON snapshot, history, runs, baselines, formula-neutralized register CSV, SysML source/projection losses and SVG diagrams with an index. Each supported retained RBD run has a schematic generated from that run's original snapshot and topology. Bow-tie and FTA SVGs describe the current snapshot. If a drawing exceeds a bound or contains invalid logic, the index records the blocked reason; no partial drawing is reported as complete. Cut-set CSV and full FTA run JSON can also be downloaded directly from the analysis view.

SysML retains the existing small `rams-structure-requirements/0.1` projection: item occurrences and requirement prose only. New fault-tree and barrier-allocation semantics remain in the JSON sidecar and explicit loss accounting. Graphical export is not native RAAML, SysML FTA semantics or a receiving-tool round trip.

## Subsequent method gates

Event-tree analysis, LOPA, STPA/control-structure analysis, quantitative criticality/prediction libraries, FRACAS and field-data fitting, operational-availability/maintenance simulation, dependency/CCF/dynamic FTA, importance/uncertainty analysis and SIL/THR assessment remain explicit later method gates. Each needs its own input contract, graph semantics, solver checks and usable report; none is claimed by the current method menu. Major-program collaboration, permissions, supplier merge and receiving-tool SysML/requirements exchange also remain production gates.

## Importance and deterministic scenarios

For independent monotone failure logic, Birnbaum importance is `B_i = Q(top | q_i=1) − Q(top | q_i=0)` and improvement potential is `q_i B_i`. These quantities depend on the mission/horizon and all other input probabilities. They need not sum to system failure probability, and do not account for severity, uncertainty, improvement cost or operational repair.

RBD derivatives follow the validated series/active-parallel tree. FTA derivatives use one Boolean variable per shared event ID. The retained run must pass same-producer replay; incompatible or tampered runs are refused. Scenarios vary one component failure rate or event probability by ×0.5 or ×2. Inputs outside the supported domain are refused rather than clipped. These are deterministic sensitivity cases, not uncertainty bounds.
