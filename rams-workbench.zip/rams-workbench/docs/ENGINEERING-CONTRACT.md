# Engineering contract — 0.2

## Study authority and identity

The workbench records a study, its assumptions and local declarations. A project has a stable local ID and monotonically increasing working revision. Records have stable IDs, immutable kinds and record revisions. Typed relationships distinguish containment, type/instance, operating context, causal contribution, control, implementation and verification. A record title or path is not identity.

Each mutation validates the candidate graph and commits its content, project revision and history in one SQLite transaction. The client supplies the expected project revision. A competing edit produces a conflict and no partial update. Containment has one parent per physical item, no cycles and a maximum depth of 100. Use dependency links for shared support rather than duplicating an instance.

Current admission limits are 10,000 records and 50,000 links per project, 20 MB per request, 100,000 JSON-data characters per record, 1,000 distinct numerical component instances and RBD depth 24. These are bounds, not demonstrated practical capacity for every graph, history volume or browser. The local scale probe covered a narrower declared fixture.

## Risk and evidence

Risk policy is project data. An optional `risk_matrix` has an ID, revision, source, severity/frequency class lists and explicit cell mappings to categories. Duplicate cells and unknown cell definitions are rejected. Missing/unmapped hazard classes remain `unassessed`; a missing value never becomes zero or low risk. Categories are not summed, averaged or multiplied into program risk. Lookup does not accept a risk.

A hazard retains its system boundary, mode, assessment classes, owner and recorded decision. A non-pending decision needs a declared authority, date, rationale, evidence reference and hazard basis revision. The server binds a changed decision to the project's engineering-content identity. That identity includes engineering descriptions, data, criteria, links and archive status, and excludes decision acknowledgements, record revision counters and non-archived workflow labels. Engineering changes conservatively flag all earlier decisions for review. A decision update alone does not invalidate other decisions. Imported decisions retain their statement and provenance but need review in the new project scope.

Coverage walks every linked control and every implementing requirement. A requirement without verification remains a gap even if another requirement has a passing result. A declared verification needs result `pass`, artifact/revision, configuration, applicability and reviewer metadata to avoid the metadata gap. Requirements may declare explicit obligation IDs, modes and configurations. Coverage requires a passing declaration matching each obligation and the current requirement revision; a normal-mode or old-revision declaration cannot close another obligation. Requirements without explicit obligations retain legacy declaration-level checking; completeness of the obligation set remains an engineering review. Verification may retain up to 32 KiB of file bytes with a validated SHA-256, filename and media type. Save/import detects byte/hash mismatch. External artifact references remain uninspected. Neither content identity nor matching metadata establishes evidence adequacy, proves execution or authenticates a reviewer. Recorded acceptance never hides an evidence or criteria gap in the attention count.

## Numerical quantities

Every calculated leaf is a distinct active physical instance with a constant exponential failure rate `lambda > 0` in `1/h` and exponential mean active repair time `m > 0` in hours. The exact component operating-mode string must match the analysis. Source, conditions, dependency-review disposition and rationale are required. Each component event must be explicitly declared `reviewed_independent`; the study must declare `reviewed_independent` or `factored_shared_support`. `unreviewed` or unresolved dispositions block calculation. Zero-rate/infinite-life and zero-time-repair idealizations are not admitted in this release. Mission time and repair target may be zero. Component quantity must equal one; explicitly instantiate repeated hardware.

For mission duration `t`, all items start functioning and no repairs count toward mission success:

```
R_i(t) = exp(-lambda_i * t)
Q_i(t) = -expm1(-lambda_i * t)
Series:   R = product(R_i), Q = 1 - product(1 - Q_i)
Parallel: Q = product(Q_i), R = 1 - product(1 - R_i)
```

Series failure probability uses `log1p`/`expm1` to preserve small probabilities. Active parallel means any one child suffices, every child is active, success logic is perfect, and there is no load sharing, switching delay or conditional behavior. Nested systems preserve their probability curves; there is no conversion of a parallel block to an equivalent exponential rate or MTBF.

Steady-state inherent availability is a separate evaluation of independent two-state processes. Components alternate exponential failure and active repair, with unlimited separate resources. Failure and repair continue independently of other components and system outage state:

```
A_i(infinity) = 1 / (1 + lambda_i * m_i)
U_i(infinity) = lambda_i * m_i / (1 + lambda_i * m_i)
Series:   A = product(A_i)
Parallel: U = product(U_i), A = 1 - U
```

This is not availability at mission time, achieved availability, operational availability or service-delivery availability. Detection, administrative/logistics delays, access windows, preventive maintenance, capacity constraints and shared crews are excluded.

Component maintainability is only the CDF of elapsed **active repair** time from repair start: `M_i(tau) = -expm1(-tau/m_i)`. No system-restoration CDF or repair-policy optimization is inferred.

## Applicability and rejection

The solver rejects missing/nonfinite/negative parameters, unknown distributions, mode mismatch, repeated physical leaf IDs, unsupported topology, quantity rollups, declared common-cause/dependency/standby/shared-repair fields, and dependency links involving selected components or their containment ancestors. The last guard is intentionally conservative; it does not solve a dependency graph automatically.

Physical independence is an engineering assertion. A single shared supply may be factored once as `C AND (A OR B)` when the modeled leaf events are independent under the declared boundary. Copying the same physical supply into independent branches is invalid. Different record names can still disguise the same physical item; this starter cannot infer that real-world equivalence. Review physical occurrence identity and all shared power/environment/software/maintenance/interface causes. A beta-factor model is one future method, not a universal substitute for this review.

Unrepresentable input products are rejected. Extreme-tail binary64 underflow is reported as a warning; displayed zero is not a proved exact probability. The RBD model is not a general FTA/ETA engine, CCF quantifier, Markov or Monte Carlo simulator, SIL/THR/PFD calculator, prediction-handbook implementation or safety acceptance process.

## Frozen calculations and exchange

A run stores the full study snapshot, analysis configuration, component record revisions/data, numerical result tree and curve, assumptions, warnings, kernel source hash, Python version, execution target and canonical input hash. Historical runs are never updated. Same-producer replay compares inputs and outputs; incompatible producers require restoration or an explicitly new study run. Hashes establish local identity, not external authenticity.

One atomic read transaction supplies the ZIP's current `project.json`, full history and historical baseline/run files. CSV is a formula-neutralized reporting view. JSON preserves original values and typed links. Importing `project.json` creates a **new project** with original IDs within its new namespace and the imported snapshot as lineage. It is not synchronization, idempotent supplier reimport or a database-history restore. Unchanged imports intentionally create distinct studies.

The SysML `rams-structure-requirements/0.1` projection represents item occurrence containment as `PartUsage` and requirement prose as `RequirementDefinition`. Stable external record IDs and revisions remain in documentation and JSON. Hazard/risk/causal/evidence/decision semantics and all non-containment links remain in the sidecar and are enumerated as projection limitations. No `satisfy`, `verify`, simulation behavior or native RAAML semantics are invented. There is no SysML import/write-back or qualified receiving-tool roundtrip. SVG bow-tie/FTA views describe current records; retained RBD schematic outputs use each run’s own snapshot. Diagram bounds/failures are explicit in the ZIP index. New barrier and Boolean semantics remain in the JSON sidecar, not the SysML projection.

## Structured creation, static FTA and graphical projections

New-record creation is distinct from updating a record and rejects an existing stable ID. A contextual new record plus one typed relationship commits atomically in one project revision. Stale writes and invalid endpoints roll back both. Imported provenance is read only through the configuration API. Removing/restoring a relationship creates normal revision/history entries.

`rams/fault_tree.py` is a separate static monotone AND/OR solver. Repeated basic-event IDs share one Boolean variable. Cut sets use set union, duplicate removal and absorption. Optional quantification evaluates the Boolean DAG for all disjoint truth assignments of declared independent basic-event probabilities, then sums their probability masses. It does not assume intermediate gates or overlapping cut sets are independent. The contract is 16 basic events, 256 reachable nodes, depth 24 and 10,000 intermediate cut-set candidates. Known mode mismatches, cycles, empty/unsupported gates, missing probability basis or declared dependencies block the applicable analysis. No silent approximation/truncation is used. See [method contracts](METHODS-AND-OUTPUTS.md) for event inputs, zero/one probability semantics, graphics bounds, exclusions and outputs.

Bow-tie views preserve causal paths and explicit preventive/mitigative allocations. Hazard-level controls without path allocation remain visible. The graphical view does not infer control efficacy, independence, risk reduction or acceptance. FTA drawings now use event statements, basic-event circles and AND/OR silhouettes, retain shared nodes once and preserve input-link ports through the shared dependency-free layered DAG layout. Their bounded symbol profile is not full IEC 61025 or RAAML conformance. See UNIFIED-VISUALIZATION.md for shared ownership, current dependencies, bounds and checks. RBD drawings preserve success logic separately from physical containment. SVGs are generated from records, not raster mockups. Diagram selection/editor interaction does not change engineering content until saved.

Quantitative FTA refuses a mathematically positive top-event probability that underflows to zero in binary64. Declared true zero input probabilities remain valid. Runs from a different current solver source/Python are visibly marked historical; replay still requires their exact producer.

## Browser execution and saving

The browser uses the same repository transactions, service dispatch, solvers and study projections. Pyodide executes Python/SQLite in a dedicated worker. Applied mutations are acknowledged only after an atomic IndexedDB compare-and-swap saves the complete SQLite snapshot. A competing tab cannot overwrite a newer workspace. Expected project revisions and record reconciliation remain enforced. Restore advances a separate workspace epoch so an editor opened before restoration cannot overwrite a coincidentally identical old project revision.

Restoration validates the complete candidate before replacement, requires explicit confirmation, rejects a changed preview and retains the immediately previous committed workspace for recovery. Startup/storage errors preserve the stored bytes. If initial browser storage is unavailable, a visible tab-only mode requires a downloaded backup before closing. Later save failures never silently downgrade a persistent workspace to tab-only storage. An interrupted worker must reload before editing continues.

Browser admission limits add a 64 MiB total workspace and 1,000 studies; the existing 20 MB request and method-specific limits still apply. Full snapshots cost time and memory in proportion to retained history and runs. These limits do not demonstrate practical capacity at the maximum. Data belongs to this browser and site address, with no remote backup or synchronization. Clearing site data can remove it. Runtime assets are self-hosted; local processing does not imply an offline-installable application.

A run's execution target distinguishes browser `Emscripten/wasm32` from a native host. Retained runs from another producer remain historical. Replaying requires an exact producer; importing a study never rewrites historical producer identity.
