"""Replay an exported run against the exact installed kernel and Python version."""
import argparse
import json
from pathlib import Path
from .engine import ENGINE, PRODUCER, Invalid, calculate, digest


def replay(run):
    if run.get("method") == "static_fta":
        from .fault_tree import replay as replay_fta
        return replay_fta(run)
    if run.get('engine') != ENGINE or run.get('basis', {}).get('producer') != PRODUCER:
        raise Invalid('Run producer differs from this kernel/Python. Restore the original source/runtime or create a new study run; do not silently migrate it.')
    if digest(run.get('basis')) != run.get('basis_sha256'):
        raise Invalid('Stored run basis does not match its recorded identity')
    fresh = calculate(run['snapshot']['entities'], run['basis']['config'])
    if fresh['basis_sha256'] != run['basis_sha256'] or fresh['result'] != run['result'] or fresh['curve'] != run['curve']:
        raise Invalid('Replay differs from the stored input/result record')
    return {'run': run['id'], 'matches': True, 'engine': ENGINE, 'producer': PRODUCER,
            'scope': 'Same-kernel numerical replay; not engineering acceptance or authenticated integrity.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('replay');p.add_argument('run',type=Path)
    args=parser.parse_args()
    try:
        run=json.loads(args.run.read_text())
        print(json.dumps(replay(run),indent=2))
    except (Invalid,ValueError,KeyError,OSError,TypeError) as e:
        parser.exit(1,f'Replay refused: {e}\n')


if __name__=='__main__':main()
