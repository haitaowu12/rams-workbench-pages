"""Read-only study review and trace projections, never compliance or acceptance."""
from collections import Counter, deque
from .engine import Invalid
from .repository import requirement_coverage

CONTEXT = (
    ('system_boundary', 'System boundary and exclusions'),
    ('configuration', 'Design / operational configuration'),
    ('lifecycle_phase', 'Lifecycle phase and intended decision'),
    ('operating_context', 'Operating context'),
    ('acceptance_process', 'Acceptance process and authority'),
)


def present(value):
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, list):
        return any(present(v) for v in value)
    return False


def review(snapshot):
    active = {e['id']: e for e in snapshot['entities'] if e['state'] != 'archived'}
    links = [l for l in snapshot['links'] if l['source'] in active and l['target'] in active]
    outward, inward = {}, {}
    for l in links:
        outward.setdefault((l['source'], l['relation']), []).append(l['target'])
        inward.setdefault((l['target'], l['relation']), []).append(l['source'])
    findings = []

    def add(category, record, code, message, next_step):
        findings.append(dict(category=category, record=record, code=code, message=message, next_step=next_step))

    config = snapshot['project']['config']
    for key, label in CONTEXT:
        if not present(config.get(key)):
            add('Study definition', None, 'context.' + key, label + ' is not recorded.', 'Complete project setup')
    refs = config.get('governing_standards', [])
    if (not refs and not present(config.get('governing_basis'))) or any(not isinstance(s, dict) or not present(s.get('name')) or not present(s.get('edition')) for s in refs):
        add('Study definition', None, 'context.references', 'Governing references need explicit names and editions, or a documented non-standard basis.', 'Review governing references')

    for e in active.values():
        i, k, d = e['id'], e['kind'], e['data']
        required = []
        if k == 'hazard':
            required = [('mode', 'Operating mode'), ('boundary', 'Hazard boundary'), ('owner', 'Assessment owner')]
            if not outward.get((i, 'applies_to')):
                add('Hazards & barriers', i, 'hazard.scope', 'Hazard has no declared item, function or interface allocation.', 'Link the assessed scope')
            if not inward.get((i, 'causes')) or not outward.get((i, 'causes')):
                add('Hazards & barriers', i, 'hazard.paths', 'Cause or consequence paths are missing.', 'Review the causal boundary')
        elif k == 'control':
            required = [('owner', 'Barrier owner'), ('status', 'Implementation status'), ('performance_standard', 'Measurable performance criterion'), ('degradation', 'Degradation / unavailability conditions')]
            if not inward.get((i, 'implements')):
                add('Hazards & barriers', i, 'control.requirement', 'No requirement implements this control.', 'Add or link an implementing requirement')
            if not any(outward.get((i, r)) for r in ('controls', 'prevents', 'mitigates')):
                add('Hazards & barriers', i, 'control.path', 'Control has no hazard or causal-path allocation.', 'Allocate the barrier')
        elif k == 'failure_mode':
            required = [('function', 'Required function'), ('mode', 'Operating mode'), ('causes', 'Failure causes / unknown-cause disposition'), ('local_effect', 'Local effect'), ('next_effect', 'Next-level effect'), ('system_effect', 'End / system effect'), ('detection', 'Detection'), ('response', 'Compensating provision / response'), ('severity', 'Severity classification'), ('criticality_basis', 'Criticality method / assessment basis'), ('source', 'Design / analysis source')]
            if not outward.get((i, 'fails')):
                add('FMEA / FMECA', i, 'fm.scope', 'Failure mode has no item or function allocation.', 'Link the item or function that fails')
            if not outward.get((i, 'causes')) and not present(d.get('hazard_disposition')):
                add('FMEA / FMECA', i, 'fm.hazard', 'No linked hazard or rationale for no hazard transfer.', 'Review the hazard-log transfer')
        elif k == 'study_node':
            required = [('intent', 'Design intent'), ('mode', 'Operating mode'), ('session', 'Study session'), ('participants', 'Study participants'), ('source', 'Design source / revision')]
            if not outward.get((i, 'studies')):
                add('HAZOP', i, 'node.scope', 'Study node has no declared item, function or interface.', 'Link the examined scope')
        elif k == 'deviation':
            required = [('parameter', 'Parameter / activity'), ('guideword', 'Guide word')]
            disposition = d.get('examination', 'finding')
            if disposition not in ('finding', 'no_issue', 'deferred', 'not_applicable'):
                add('HAZOP', i, 'deviation.disposition', 'Unknown examination disposition.', 'Choose a supported disposition')
            if disposition == 'finding':
                required += [('causes', 'Credible causes'), ('consequences', 'Consequences'), ('safeguards', 'Existing safeguard / no-safeguard disposition')]
                if not outward.get((i, 'causes')) and not present(d.get('hazard_disposition')):
                    add('HAZOP', i, 'deviation.hazard', 'Finding has no linked hazard or no-transfer rationale.', 'Review the hazard-log transfer')
                if present(d.get('recommendations')) and not inward.get((i, 'addresses')):
                    add('HAZOP', i, 'deviation.action', 'Recommendations have no linked action or disposition record.', 'Create an action with owner and completion evidence')
            elif not present(d.get('examination_basis')):
                add('HAZOP', i, 'deviation.basis', 'Examination disposition has no supporting rationale.', 'Record the examination / deferral basis')
            if disposition == 'deferred':
                add('HAZOP', i, 'deviation.deferred', 'This examination remains deferred.', 'Resolve the deferred examination')
            if not outward.get((i, 'deviates')):
                add('HAZOP', i, 'deviation.node', 'Examination is not linked to a study node.', 'Link the design intent being examined')
        elif k == 'srac':
            required = [('condition', 'Application condition'), ('receiving_owner', 'Receiving owner'), ('acceptance', 'Receiving disposition'), ('acceptance_reference', 'Receiving decision reference')]
        elif k == 'assumption':
            required = [('rationale', 'Assumption basis'), ('validation_needed', 'Validation / discharge criterion'), ('owner', 'Assumption owner')]
        elif k == 'action':
            required = [('owner', 'Action owner')]
            if not present(d.get('due')) and not present(d.get('completion_evidence')):
                add('Actions & transfer', i, 'action.due', 'Open action has no due date or disposition.', 'Agree a due date or record the disposition')
        elif k == 'requirement':
            if not e['description'].strip():
                add('Requirements & evidence', i, 'requirement.text', 'Requirement statement is empty.', 'Write the requirement and measurable acceptance criterion')
            required = [('verification_method', 'Verification method')]
        category = {'failure_mode': 'FMEA / FMECA', 'study_node': 'HAZOP', 'deviation': 'HAZOP', 'hazard': 'Hazards & barriers', 'control': 'Hazards & barriers', 'requirement': 'Requirements & evidence', 'srac': 'Actions & transfer', 'assumption': 'Actions & transfer', 'action': 'Actions & transfer'}.get(k, 'Study definition')
        missing = [label for key, label in required if not present(d.get(key))]
        if missing:
            add(category, i, k + '.fields', 'Not recorded: ' + '; '.join(missing) + '.', 'Complete the record or state a justified disposition')

    for r in requirement_coverage(snapshot):
        if r['status'] != 'covered' or r['incomplete']:
            obligation = r['obligation']['id'] if r['obligation'] else 'scope undefined'
            add('Requirements & evidence', r['requirement'], 'verification.coverage', 'Verification requires review: ' + obligation + '.', 'Review current revision / mode / configuration and adverse declarations')
    inactive = [l for l in snapshot['links'] if l['source'] not in active or l['target'] not in active]
    for l in inactive:
        add('Configuration', l['source'] if l['source'] in active else l['target'] if l['target'] in active else None, 'link.archived', f"Relationship uses an archived endpoint: {l['source']} → {l['relation']} → {l['target']}.", 'Review the retained relationship before relying on the chain')
    findings.sort(key=lambda f: (f['category'], f['record'] or '', f['code'], f['message']))
    examinations = Counter(e['data'].get('examination', 'finding') for e in active.values() if e['kind'] == 'deviation')
    return dict(revision=snapshot['project']['revision'], findings=findings, categories=dict(Counter(f['category'] for f in findings)), examinations=dict(examinations), scope='Recorded-content and declared-link checks. No assessment of engineering adequacy, completeness of hazard identification, compliance or approval.')


def traceability(snapshot):
    """One row per control, plus hazards/requirements with no implementing chain.

    Arrays retain many-to-many identities without a Cartesian row explosion.
    Path allocation remains distinguished from direct hazard coverage.
    """
    active = {e['id']: e for e in snapshot['entities'] if e['state'] != 'archived'}
    outward, inward = {}, {}
    for l in snapshot['links']:
        if l['source'] not in active or l['target'] not in active:
            continue
        outward.setdefault((l['source'], l['relation']), []).append(l['target'])
        inward.setdefault((l['target'], l['relation']), []).append(l['source'])
    rows, used_hazards, used_reqs = [], set(), set()
    for e in active.values():
        if e['kind'] != 'control':
            continue
        i = e['id']
        paths = [dict(hazard=h, via=i, relation='controls') for h in outward.get((i, 'controls'), [])]
        for r, causal_direction in (('prevents', 'out'), ('mitigates', 'in')):
            for target in outward.get((i, r), []):
                related = outward.get((target, 'causes'), []) if causal_direction == 'out' else inward.get((target, 'causes'), [])
                paths += [dict(hazard=h, via=target, relation=r) for h in related if active[h]['kind'] == 'hazard']
        hazards = sorted({p['hazard'] for p in paths})
        reqs = sorted(inward.get((i, 'implements'), []))
        used_hazards.update(hazards)
        used_reqs.update(reqs)
        rows.append(dict(control=i, hazards=hazards, allocations=paths, requirements=reqs))
    rows += [dict(control=None, hazards=[i], allocations=[], requirements=[]) for i,e in active.items() if e['kind'] == 'hazard' and i not in used_hazards]
    rows += [dict(control=None, hazards=[], allocations=[], requirements=[i]) for i,e in active.items() if e['kind'] == 'requirement' and i not in used_reqs]
    rows.sort(key=lambda r: (r['control'] or '', r['hazards'], r['requirements']))
    return dict(rows=rows, coverage=requirement_coverage(snapshot), scope='Declared hazard / path → control ← requirement ← verification chains. A link records traceability, not satisfaction, effectiveness or acceptance.')


def related_records(snapshot, record, depth=3, limit=250):
    """Bounded undirected review neighborhood; paths preserve edge direction."""
    active = {e['id']: e for e in snapshot['entities'] if e['state'] != 'archived'}
    if record not in active:
        raise Invalid('Select an active engineering record')
    adjacency = {}
    for l in snapshot['links']:
        if l['source'] in active and l['target'] in active:
            adjacency.setdefault(l['source'], []).append((l['target'], l))
            adjacency.setdefault(l['target'], []).append((l['source'], l))
    seen, queue, rows, truncated = {record}, deque([(record, [])]), [], False
    while queue:
        current, path = queue.popleft()
        if len(path) >= depth:
            if any(i not in seen for i,_ in adjacency.get(current, [])):
                truncated = True
            continue
        for target, edge in sorted(adjacency.get(current, []), key=lambda pair: (pair[0], pair[1]['relation'])):
            if target in seen:
                continue
            if len(rows) >= limit:
                truncated = True
                continue
            seen.add(target)
            next_path = path + [edge]
            rows.append(dict(record=target, distance=len(next_path), path=next_path))
            queue.append((target, next_path))
    return dict(record=record, rows=rows, depth=depth, limit=limit, truncated=truncated, scope='Related records to inspect after a change, through declared links in either direction. This is not an automatic engineering impact or approval determination. Unlinked effects remain unknown.')
