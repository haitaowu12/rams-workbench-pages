"""Bounded, deterministic independent-component RBD evaluation.

Mission reliability and steady-state inherent availability are separate measures.
There is deliberately no network-equivalent MTBF or operational availability.
"""
import hashlib
import json
import math
from pathlib import Path
import platform

ENGINE = 'independent-rbd/1.0'
PRODUCER = {'engine_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'python': platform.python_version(), 'arithmetic': 'IEEE-754 binary64'}


class Invalid(ValueError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def number(value, label, minimum=0, positive=False):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise Invalid(f'{label} must be a finite number')
    if value < minimum or (positive and value == minimum):
        raise Invalid(f'{label} must be {">" if positive else ">="} {minimum}')
    return value


def calculate(entities, config):
    if not isinstance(config, dict):
        raise Invalid('Analysis configuration must be an object')
    allowed = {'name', 'mode', 'success', 'mission_hours', 'repair_target_hours', 'independence', 'dependency_status', 'tree'}
    if set(config) - allowed:
        raise Invalid('Unknown analysis fields: ' + ', '.join(sorted(set(config) - allowed)))
    for key in ('name', 'mode', 'success', 'independence'):
        if not isinstance(config.get(key), str) or not config[key].strip():
            raise Invalid(f'{key} is required; record the analysis boundary and assumptions')
    if config.get('dependency_status') not in ('reviewed_independent', 'factored_shared_support'):
        raise Invalid('Dependency/CCF review must explicitly justify independence or factored shared support; unresolved review blocks calculation')
    mission = number(config.get('mission_hours'), 'Mission time [h]')
    repair_target = number(config.get('repair_target_hours'), 'Repair target [h]')
    by_id = {e['id']: e for e in entities}
    seen = set()
    inputs = []
    warnings = []

    def walk(node, depth=0):
        if depth > 24 or not isinstance(node, dict):
            raise Invalid('Invalid RBD node or depth exceeds 24')
        if 'item' in node:
            if set(node) != {'item'} or not isinstance(node['item'], str):
                raise Invalid('A leaf must contain only an item ID')
            item_id = node['item']
            if item_id in seen:
                raise Invalid(f'Repeated instance {item_id}: this independent RBD cannot evaluate shared events')
            seen.add(item_id)
            if len(seen) > 1000:
                raise Invalid('This solver supports at most 1000 distinct component instances')
            item = by_id.get(item_id)
            if not item or item['kind'] != 'item' or item.get('state') == 'archived':
                raise Invalid(f'Active component instance not found: {item_id}')
            d = item.get('data', {})
            required = {'model', 'rate_per_hour', 'mean_active_repair_hours', 'mode', 'source', 'conditions', 'dependency_review', 'dependency_status'}
            if not required <= d.keys():
                raise Invalid(f'{item_id}: missing RAM input fields: {", ".join(sorted(required-d.keys()))}')
            if d['model'] != 'exponential' or d['mode'] != config['mode']:
                raise Invalid(f'{item_id}: exponential model and exact operating-mode match required')
            if d['dependency_status'] != 'reviewed_independent':
                raise Invalid(f'{item_id}: unresolved component-event dependency review')
            for k in ('source', 'conditions', 'dependency_review'):
                if not isinstance(d[k], str) or not d[k].strip():
                    raise Invalid(f'{item_id}: {k} is required')
            if d.get('dependencies') or d.get('common_cause_group') or d.get('standby') or d.get('shared_repair'):
                raise Invalid(f'{item_id}: dependency, standby or shared repair requires a different solver')
            if d.get('quantity', 1) != 1:
                raise Invalid(f'{item_id}: instantiate each physical component explicitly; quantity rollup is unsupported')
            rate = number(d['rate_per_hour'], f'{item_id} failure rate [1/h]', positive=True)
            repair = number(d['mean_active_repair_hours'], f'{item_id} mean active repair [h]', positive=True)
            load = rate * mission
            if not math.isfinite(load) or not math.isfinite(rate * repair):
                raise Invalid(f'{item_id}: numeric range exceeded')
            if (mission > 0 and load == 0) or rate * repair == 0:
                raise Invalid(f'{item_id}: input product underflows the supported floating-point range')
            r = math.exp(-load)
            q = -math.expm1(-load)
            if r == 0:
                warnings.append(f'{item_id}: mission reliability underflowed to 0 in binary64; use a log-domain solver for extreme-tail studies.')
            a = 1 / (1 + rate * repair)
            u = rate * repair / (1 + rate * repair)
            m = -math.expm1(-repair_target / repair)
            inputs.append({'id': item_id, 'revision': item['revision'], 'title': item['title'], 'data': d})
            return {'item': item_id, 'mission_reliability': r, 'mission_failure_probability': q,
                    'inherent_availability': a, 'inherent_unavailability': u, 'repair_completion_probability': m}
        if set(node) != {'op', 'children'} or node.get('op') not in ('series', 'parallel'):
            raise Invalid('Use item leaves or op=series/parallel with children')
        if not isinstance(node['children'], list) or not 2 <= len(node['children']) <= 1000:
            raise Invalid('A series/parallel gate needs 2 to 1000 children')
        children = [walk(c, depth+1) for c in node['children']]
        if node['op'] == 'series':
            r = math.prod(c['mission_reliability'] for c in children)
            q = -math.expm1(sum(math.log1p(-c['mission_failure_probability']) for c in children)) if all(c['mission_failure_probability'] < 1 for c in children) else 1.0
            a = math.prod(c['inherent_availability'] for c in children)
            u = -math.expm1(sum(math.log1p(-c['inherent_unavailability']) for c in children)) if all(c['inherent_unavailability'] < 1 for c in children) else 1.0
        else:
            q = math.prod(c['mission_failure_probability'] for c in children)
            r = -math.expm1(sum(math.log(c['mission_failure_probability']) for c in children)) if all(c['mission_failure_probability'] > 0 for c in children) else 1.0
            u = math.prod(c['inherent_unavailability'] for c in children)
            a = 1 - u
        if mission > 0 and (r == 0 or q == 0):
            warnings.append(f'{node["op"]} gate reached a binary64 probability boundary; inspect underflow before using extreme-tail results.')
        return {'op': node['op'], 'mission_reliability': r, 'mission_failure_probability': q,
                'inherent_availability': a, 'inherent_unavailability': u, 'children': children}

    result = walk(config.get('tree'))
    curves = []
    # Preserve curve evaluation through the actual topology; no equivalent-rate shortcut.
    def reliability(node, t):
        if 'item' in node:
            return math.exp(-by_id[node['item']]['data']['rate_per_hour'] * t)
        values = [reliability(c, t) for c in node['children']]
        return math.prod(values) if node['op'] == 'series' else 1-math.prod(1-v for v in values)
    for n in range(21):
        t = mission*n/20
        curves.append({'hours': t, 'reliability': reliability(config['tree'], t)})
    basis = {'engine': ENGINE, 'producer': PRODUCER, 'config': config, 'inputs': sorted(inputs, key=lambda x: x['id'])}
    return {'engine': ENGINE, 'basis_sha256': digest(basis), 'basis': basis, 'result': result,
            'curve': curves, 'warnings': warnings, 'applicability': [
                'Non-repairable mission reliability: all required items initially functioning; constant component rates.',
                'Steady-state inherent availability: independent alternating exponential failure/active-repair processes; unlimited separate repair resources.',
                'Parallel means active redundancy, perfect success logic, no switching or load sharing.',
                'Repair-completion probability is component-only; exponential active repair, not system restoration or logistics.',
                'Independence and applicability are user declarations, not software-verified facts.',
                'No operational availability, THR, SIL, PFDavg, network MTBF or risk-acceptance conclusion.'
            ]}
