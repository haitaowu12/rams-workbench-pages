"""Portable full-study presentation using the workbench's own interface."""
from pathlib import Path
from .engine import canonical, Invalid, PRODUCER as RBD_PRODUCER
from .fault_tree import PRODUCER as FTA_PRODUCER
from .repository import coverage, requirement_coverage, KINDS, STATES, RELATIONS
from .diagrams import bowtie, fault_tree, rbd, projection
from . import VERSION
from .technical_review import review, traceability
ROOT=Path(__file__).resolve().parents[1]

def run_summary(run):
    return dict(id=run['id'],revision=run['project_revision'],at=run['at'],name=run['basis']['config']['name'],method=run.get('method','rbd'),config=run['basis']['config'],result=run['result'])

def study_payload(archive):
    snapshot=archive['snapshot']
    drawings={}
    for e in snapshot['entities']:
        if e['state']=='archived' or e['kind'] not in ('hazard','fault_gate'):continue
        kind='bowtie' if e['kind']=='hazard' else 'fta'
        key=kind+':'+e['id']
        try:
            svg=bowtie(snapshot,e['id'])[0] if kind=='bowtie' else fault_tree(snapshot,e['id'])
            drawings[key]=dict(svg=svg,source=projection(snapshot,kind,e['id']))
        except Invalid as error:drawings[key]=dict(error=str(error))
    for item in archive['runs']:
        run=item['body']
        if run.get('method')=='static_fta':continue
        try:drawings['rbd:'+run['id']]=dict(svg=rbd(run['snapshot'],run['basis']['config']['tree']),source=projection(run['snapshot'],'rbd',tree=run['basis']['config']['tree']))
        except Invalid as error:drawings['rbd:'+run['id']]=dict(error=str(error))
    return dict(snapshot={**snapshot,'coverage':coverage(snapshot),'requirement_coverage':requirement_coverage(snapshot)},technical_review=review(snapshot),traceability=traceability(snapshot),runs=archive['runs'],baselines=archive['baselines'],history=archive['history'],drawings=drawings,info=dict(version=VERSION,kinds=KINDS,states=STATES,relations=list(RELATIONS),producers=dict(rbd=RBD_PRODUCER,fta=FTA_PRODUCER)),records=dict(history=list(reversed(archive['history'])),baselines=archive.get('baseline_metadata', []),runs=[run_summary(r['body']) for r in reversed(archive['runs'])]))

def portable_html(archive):
    payload=study_payload(archive)
    html=(ROOT/'web/index.html').read_text()
    for url,path in [('/style.css',ROOT/'web/style.css'),('/unified/engineering-view.css',ROOT/'vendor/unified_visuals/engineering-view.css')]:
        html=html.replace(f'<link rel="stylesheet" href="{url}" />','<style>'+path.read_text()+'</style>')
    html=html.replace('<script type="module" src="/app.js"></script>','')
    source=(ROOT/'web/app.js').read_text().replace('import "/unified/engineering-view.js";','')
    source=source.replace('import { actionState, sortedActions, mergeDraft } from "/workflow-model.js";', (ROOT/'web/workflow-model.js').read_text().replace('export function ', 'function '))
    runtime=(ROOT/'vendor/unified_visuals/engineering-view.js').read_text()
    data=canonical(payload).replace('<','\\u003c').replace('&','\\u0026')
    scripts='<script id="study-data" type="application/json">'+data+'</script><script>'+runtime.replace('</script','<\\/script')+'</script><script type="module">'+source.replace('</script','<\\/script')+'</script>'
    return html.replace('</body>',scripts+'</body>')
