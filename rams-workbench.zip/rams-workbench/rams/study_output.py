"""Portable full-study presentation using the workbench's own interface."""
from pathlib import Path
import base64
import re
from .engine import canonical, Invalid, PRODUCER as RBD_PRODUCER
from .fault_tree import PRODUCER as FTA_PRODUCER
from .repository import coverage, requirement_coverage, KINDS, STATES, RELATIONS
from .diagrams import bowtie, fault_tree, rbd, projection
from . import VERSION
from .technical_review import review, traceability
ROOT=Path(__file__).resolve().parents[1]

def run_summary(run):
    return dict(id=run['id'],revision=run['project_revision'],at=run['at'],name=run['basis']['config']['name'],method=run.get('method','rbd'),config=run['basis']['config'],result=run['result'])

def study_payload(archive):
    snapshot=archive['snapshot']
    drawings={}
    for e in snapshot['entities']:
        if e['state']=='archived' or e['kind'] not in ('hazard','fault_gate'):continue
        kind='bowtie' if e['kind']=='hazard' else 'fta'
        key=kind+':'+e['id']
        try:
            svg=bowtie(snapshot,e['id'])[0] if kind=='bowtie' else fault_tree(snapshot,e['id'])
            drawings[key]=dict(svg=svg,source=projection(snapshot,kind,e['id']))
        except Invalid as error:drawings[key]=dict(error=str(error))
    for item in archive['runs']:
        run=item['body']
        if run.get('method')=='static_fta':continue
        try:drawings['rbd:'+run['id']]=dict(svg=rbd(run['snapshot'],run['basis']['config']['tree']),source=projection(run['snapshot'],'rbd',tree=run['basis']['config']['tree']))
        except Invalid as error:drawings['rbd:'+run['id']]=dict(error=str(error))
    return dict(snapshot={**snapshot,'coverage':coverage(snapshot),'requirement_coverage':requirement_coverage(snapshot)},technical_review=review(snapshot),traceability=traceability(snapshot),runs=archive['runs'],baselines=archive['baselines'],history=archive['history'],drawings=drawings,info=dict(version=VERSION,kinds=KINDS,states=STATES,relations=list(RELATIONS),producers=dict(rbd=RBD_PRODUCER,fta=FTA_PRODUCER)),records=dict(history=list(reversed(archive['history'])),baselines=archive.get('baseline_metadata', []),runs=[run_summary(r['body']) for r in reversed(archive['runs'])]))

def portable_html(archive):
    payload=study_payload(archive)
    html=(ROOT/'web/index.html').read_text().replace('href="./guide/"', 'href="https://haitaowu12.github.io/rams-workbench-pages/guide/"')
    for url,path in [('./style.css',ROOT/'web/style.css'),('./unified/engineering-view.css',ROOT/'vendor/unified_visuals/engineering-view.css')]:
        css=path.read_text()
        for font in (ROOT/'web/fonts').glob('*.woff2'):
            css=css.replace('./fonts/'+font.name,'data:font/woff2;base64,'+base64.b64encode(font.read_bytes()).decode())
        html=html.replace(f'<link rel="stylesheet" href="{url}" />','<style>'+css+'</style>')
    for asset in ('logo.svg','favicon.svg'):
        data_url='data:image/svg+xml;base64,'+base64.b64encode((ROOT/'web'/asset).read_bytes()).decode()
        html=html.replace('./'+asset,data_url)
    font_license=(ROOT/'web/fonts/ibm-plex-sans-LICENSE.txt').read_text()
    html=html.replace('</head>','<script type="text/plain" id="font-license">'+font_license+'</script>\n</head>')
    html=html.replace('<script type="module" src="./app.js"></script>','')
    source=(ROOT/'web/app.js').read_text().replace('import "./unified/engineering-view.js";','')
    workflow=(ROOT/'web/workflow-model.js').read_text().replace('export function ', 'function ').replace('export const ', 'const ')
    source=re.sub(r'import \{[^}]*\} from "\./workflow-model\.js";',lambda match:workflow,source)
    source=source.replace('import { request, browserRuntime, runtimeReady, uiStorage } from "./transport.js";', 'const browserRuntime=null, runtimeReady=Promise.resolve(); const uiStorage={getItem(k){try{return localStorage.getItem(k)}catch{return null}},setItem(k,v){try{localStorage.setItem(k,v)}catch{}},removeItem(k){try{localStorage.removeItem(k)}catch{}}};')
    runtime=(ROOT/'vendor/unified_visuals/engineering-view.js').read_text()
    data=canonical(payload).replace('<','\\u003c').replace('&','\\u0026')
    scripts='<script id="study-data" type="application/json">'+data+'</script><script>'+runtime.replace('</script','<\\/script')+'</script><script type="module">'+source.replace('</script','<\\/script')+'</script>'
    return html.replace('</body>',scripts+'</body>')
