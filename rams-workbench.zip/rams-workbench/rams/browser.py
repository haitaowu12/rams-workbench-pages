"""In-process browser transport. Uses the same service, repository and solvers as the local app."""
import hashlib,json,platform,sqlite3
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from .engine import canonical,Invalid
from .repository import Repository,Conflict,validate_entities,validate_config
from .storage import snapshot_bytes,inspect_connection
from .service import dispatch,Reply

DATABASE=Path('/workspace/studies.sqlite3')
repo=None

def replace_workspace(data):
    global repo
    DATABASE.parent.mkdir(exist_ok=True)
    for suffix in ('','-wal','-shm'):
        Path(str(DATABASE)+suffix).unlink(missing_ok=True)
    if data is not None:DATABASE.write_bytes(bytes(data))
    repo=Repository(DATABASE)

def workspace_bytes():
    return snapshot_bytes(DATABASE)

def validate_workspace(data):
    """Inspect before replacing anything; preserve all historical run identities."""
    path=DATABASE.with_name('candidate.sqlite3')
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(bytes(data))
    try:
        db=sqlite3.connect(path)
        try:counts=inspect_connection(db)
        finally:db.close()
        candidate=Repository(path)
        projects=candidate.projects()
        if len(projects)>1000:raise Invalid('Browser workspace limit: 1,000 studies')
        for project in projects:
            snapshot=candidate.get(project['id'])
            validate_entities(snapshot['entities'],snapshot['links'])
            validate_config(snapshot['project']['config'])
            candidate.archive(project['id'])
        return dict(counts=counts,projects=projects,sha256=hashlib.sha256(bytes(data)).hexdigest())
    except (sqlite3.Error, ValueError, KeyError, TypeError) as error:
        raise Invalid('The file is not a valid RAMS workspace backup: '+str(error)) from error
    finally:
        for suffix in ('','-wal','-shm'):Path(str(path)+suffix).unlink(missing_ok=True)

def request(raw):
    def invalid(value):raise Invalid('Nonfinite JSON number: '+value)
    try:
        data=json.loads(raw,parse_constant=invalid)
        u=urlparse(data['path'])
        post='body' in data
        if post and not isinstance(data['body'],dict):raise Invalid('JSON object required')
        result=dispatch(repo,'POST' if post else 'GET',u.path,parse_qs(u.query),data.get('body'),
                        health=dict(deployment='browser',python=platform.python_version(),capability_revision='browser-workflows/1'))
        if post and result.status<400 and len(repo.projects())>1000:raise Invalid('Browser workspace limit: 1,000 studies')
    except Conflict as error:result=Reply(dict(error=str(error)),409)
    except (Invalid,ValueError,TypeError,KeyError,RecursionError,sqlite3.Error) as error:result=Reply(dict(error=str(error)),400)
    return dict(status=result.status,content_type=result.content_type,filename=result.filename,body=result.bytes())
