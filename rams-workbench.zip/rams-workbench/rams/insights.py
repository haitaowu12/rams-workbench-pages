"""Replay-checked, read-only importance at a retained mission / event horizon.

Birnbaum is dQ(top)/dq(i). Perfect/failed interventions are hypothetical
probability substitutions, never approved design changes or availability models.
"""
import hashlib
import math
from pathlib import Path
from .engine import Invalid

METHOD = 'independent-mission-importance/1'
PRODUCER = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def _combine(op, values):
    if op == 'parallel':
        return math.prod(values)
    return -math.expm1(math.fsum(math.log1p(-q) for q in values)) if all(q < 1 for q in values) else 1.0


def _rbd(run):
    root = run['result']
    inputs = {e['id']: e for e in run['basis']['inputs']}
    values, derivatives = {}, {}

    def walk(node, factor=1.0):
        if 'item' in node:
            values[node['item']] = node['mission_failure_probability']
            derivatives[node['item']] = factor
            return
        children = node['children']
        # Prefix/suffix products avoid division at zero and quadratic fanout.
        factors = [(1-c['mission_failure_probability']) if node['op'] == 'series' else c['mission_failure_probability'] for c in children]
        prefix, suffix = [1.0], [1.0] * (len(factors)+1)
        for q in factors:
            prefix.append(prefix[-1] * q)
        for i in range(len(factors)-1, -1, -1):
            suffix[i] = suffix[i+1] * factors[i]
        for i, child in enumerate(children):
            walk(child, factor * prefix[i] * suffix[i+1])

    def intervention(node, target, probability):
        if 'item' in node:
            return probability if node['item'] == target else node['mission_failure_probability']
        return _combine(node['op'], [intervention(c, target, probability) for c in node['children']])

    walk(root)
    rows = []
    for i in sorted(values):
        d = inputs[i]['data']
        scenarios = []
        for factor in (0.5, 2.0):
            load = d['rate_per_hour'] * run['basis']['config']['mission_hours'] * factor
            if not math.isfinite(load) or (run['basis']['config']['mission_hours'] > 0 and load == 0):
                scenarios.append(dict(factor=factor, probability=None, reason='Scenario exceeds binary64 range'))
            else:
                p = -math.expm1(-load)
                scenarios.append(dict(factor=factor, probability=intervention(root, i, p), reason=None))
        rows.append(dict(record=i, title=inputs[i]['title'], input_probability=values[i], birnbaum=derivatives[i], perfect_probability=intervention(root, i, 0.0), failed_probability=intervention(root, i, 1.0), scenarios=scenarios))
    return rows, root['mission_failure_probability'], 'Component failure rate × factor; all other inputs fixed'


def _fta(run):
    if run['result']['top_event_probability'] is None:
        raise Invalid('Importance requires a quantified FTA run with applicable independent-event probabilities')
    inputs = {e['id']: e for e in run['basis']['inputs'] if e['kind'] == 'fault_event'}
    ids = sorted(inputs)
    if not 1 <= len(ids) <= 16:
        raise Invalid('Importance is bounded to 16 distinct basic events')
    states = 1 << len(ids)
    vectors = {event: int.from_bytes(bytes((a >> i) & 1 for a in range(states)), 'little') for i,event in enumerate(ids)}
    # Minimal cut sets are the exact monotone Boolean function, including shared
    # identities. OR of intersections; never sum overlapping cut-set masses.
    truth = 0
    for cut in run['result']['minimal_cut_sets']:
        v = vectors[cut[0]]
        for event in cut[1:]:
            v &= vectors[event]
        truth |= v
    truth = truth.to_bytes(states, 'little')
    probs = [inputs[i]['data']['probability'] for i in ids]
    rows = []
    for index, event in enumerate(ids):
        bit = 1 << index
        zero_terms, one_terms, pivotal = [], [], []
        # Enumerate each assignment of all OTHER events once. No division by
        # p or 1-p, so declared zero / one inputs remain defined.
        for a in range(states):
            if a & bit:
                continue
            mass = math.prod(p if a & (1 << j) else 1-p for j,p in enumerate(probs) if j != index)
            if truth[a]:
                zero_terms.append(mass)
            if truth[a | bit]:
                one_terms.append(mass)
                if not truth[a]:
                    pivotal.append(mass)
        q0, q1, b = math.fsum(zero_terms), math.fsum(one_terms), math.fsum(pivotal)
        scenarios = []
        for factor in (0.5, 2.0):
            p = probs[index] * factor
            if p > 1:
                scenarios.append(dict(factor=factor, probability=None, reason='Probability would exceed 1; scenario refused'))
            else:
                scenarios.append(dict(factor=factor, probability=math.fsum([q0, p*b]), reason=None))
        rows.append(dict(record=event, title=inputs[event]['title'], input_probability=probs[index], birnbaum=b, perfect_probability=q0, failed_probability=q1, scenarios=scenarios))
    return rows, run['result']['top_event_probability'], 'Basic-event probability × factor at the retained mode / horizon; values above 1 refused'


def importance(run):
    from .__main__ import replay
    replay(run)  # Refuse changed / legacy producers and tampered input/results.
    rows, probability, scenario_basis = _fta(run) if run.get('method') == 'static_fta' else _rbd(run)
    for row in rows:
        for key in ('input_probability', 'birnbaum', 'perfect_probability', 'failed_probability'):
            if not math.isfinite(row[key]) or not 0 <= row[key] <= 1+1e-12:
                raise Invalid('Importance probability arithmetic failed; no partial result returned')
        # Improvement potential uses p*B to preserve small differences. It is
        # not a percentage allocation; individual potentials need not sum to Q.
        row['improvement_potential'] = row['input_probability'] * row['birnbaum']
    rows.sort(key=lambda row: (-row['improvement_potential'], row['record']))
    return dict(method=METHOD, producer_sha256=PRODUCER, run=run['id'], basis_sha256=run['basis_sha256'], project_revision=run['project_revision'], mode=run['basis']['config']['mode'], mission_hours=run['basis']['config']['mission_hours'], probability=probability, rows=rows, warnings=list(run.get('warnings', [])) + ['Binary64 boundaries apply to derived probabilities and importance. A displayed zero does not prove a physically impossible event.'], scenario_basis=scenario_basis, scope='Same-producer replay checked. Independent static mission / event-horizon probabilities only. Importance is conditional on this model and its data; it does not assess engineering severity, uncertainty, cost, control efficacy or acceptance. Availability and repair importance are not calculated.', definitions={'birnbaum': 'Q(top | event i forced failed) − Q(top | event i forced functioning); computed without subtractive cancellation.', 'improvement_potential': 'q(i) × Birnbaum: reduction in top / mission failure probability if this input were perfect, with other inputs fixed.', 'scenarios': 'One input varied at a time. Factors are deterministic stress cases, not confidence intervals or parameter uncertainty distributions.'})
