"""A complete fictional study, built through the normal repository operations."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def complete_study(repo):
    snapshot=repo.create('Station systems — complete demonstration study',json.loads((ROOT/'examples/complete-station.json').read_text()))
    project=snapshot['project']
    for config in json.loads((ROOT/'examples/complete-station-rams.json').read_text()):
        repo.analyze(project['id'],project['revision'],config)
    repo.analyze_fault_tree(project['id'],project['revision'],dict(name='Indication loss — shared initiating event',top='FT_TOP',mode='normal',mission_hours=100,quantify=True,independence='Synthetic independent basic events at a 100 h horizon; the shared initiator retains one identity.'))
    repo.baseline(project['id'],project['revision'],'Complete demonstration baseline')
    return snapshot
