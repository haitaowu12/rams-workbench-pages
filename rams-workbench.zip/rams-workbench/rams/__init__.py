"""RAMS Workbench: local engineering study foundation, version 0.3.0-dev1."""
VERSION = '0.3.0-dev1'
