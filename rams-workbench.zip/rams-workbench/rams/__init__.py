"""RAMS Workbench: browser and local engineering study application."""
VERSION = '0.4.0'
