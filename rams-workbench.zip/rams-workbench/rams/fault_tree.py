"""Bounded static AND/OR fault trees; exact shared-event Boolean identity.

Qualitative cut sets are not probabilities. Quantification uses independent
basic-event probabilities at one explicitly matching horizon and mode.
"""
import hashlib
import math
from pathlib import Path
import platform
from .engine import Invalid, digest

ENGINE = 'static-and-or-fta/1.0'
PRODUCER = {'engine_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'python': platform.python_version(), 'arithmetic': 'IEEE-754 binary64'}


def calculate(snapshot, config):
    if not isinstance(config, dict) or set(config) != {'name', 'top', 'mode', 'mission_hours', 'quantify', 'independence'}:
        raise Invalid('FTA configuration requires name, top, mode, mission_hours, quantify and independence')
    for key in ('name', 'top', 'mode'):
        if not isinstance(config[key], str) or not config[key].strip(): raise Invalid('FTA '+key+' is required')
    if not isinstance(config['independence'], str): raise Invalid('FTA independence must be text')
    if type(config['quantify']) is not bool: raise Invalid('FTA quantify must be a boolean')
    t = config['mission_hours']
    if type(t) not in (int, float) or not math.isfinite(t) or t < 0: raise Invalid('FTA mission duration must be finite and nonnegative')
    by_id = {e['id']: e for e in snapshot['entities'] if e['state'] != 'archived'}
    children = {}
    for l in snapshot['links']:
        if l['relation'] == 'input_to': children.setdefault(l['target'], []).append(l['source'])
    visiting, memo, used, events = set(), {}, set(), set()
    def absorb(candidates):
        if len(candidates) > 10000: raise Invalid('FTA cut-set expansion exceeds 10,000 candidates; use a qualified larger solver')
        kept = []
        for c in sorted(set(candidates), key=lambda x: (len(x), sorted(x))):
            if not any(k <= c for k in kept): kept.append(c)
        return kept
    def visit(node_id, depth=0):
        if depth > 24: raise Invalid('FTA depth exceeds 24')
        if node_id in visiting: raise Invalid('Fault-tree cycle')
        if node_id in memo: return memo[node_id]
        if node_id not in by_id: raise Invalid('Fault-tree input is missing or archived: '+node_id)
        used.add(node_id)
        if len(used) > 256: raise Invalid('FTA bound is 256 reachable nodes')
        node = by_id[node_id]
        if node['data'].get('mode') not in (None, '', config['mode']): raise Invalid(node_id+': declared mode does not match the FTA')
        if node['kind'] == 'fault_event':
            events.add(node_id)
            if len(events) > 16: raise Invalid('FTA bound is 16 distinct basic events')
            result = [frozenset([node_id])]
        elif node['kind'] == 'fault_gate':
            logic = node['data'].get('logic')
            if logic not in ('AND', 'OR'): raise Invalid('Supported fault gates are AND and OR')
            ids = sorted(children.get(node_id, []))
            if not ids: raise Invalid('Fault gate has no inputs: '+node_id)
            visiting.add(node_id)
            parts = [visit(i, depth+1) for i in ids]
            visiting.remove(node_id)
            if logic == 'OR': result = absorb([c for part in parts for c in part])
            else:
                result = [frozenset()]
                for part in parts:
                    if len(result)*len(part) > 10000: raise Invalid('FTA cut-set expansion exceeds 10,000 candidates')
                    result = absorb([a | b for a in result for b in part])
        else: raise Invalid('Fault-tree nodes must be fault_event or fault_gate')
        memo[node_id] = result
        return result
    cut_sets = visit(config['top'])
    event_ids = sorted(events)
    probability = None
    if config['quantify']:
        if not isinstance(config['independence'], str) or not config['independence'].strip():
            raise Invalid('Quantitative FTA needs an explicit independence boundary and rationale')
        mapped = set(used)
        for l in snapshot['links']:
            if l['source'] in events and l['relation'] == 'applies_to': mapped.add(l['target'])
        parents = {l['target']: l['source'] for l in snapshot['links'] if l['relation'] == 'contains'}
        for item in list(mapped):
            while item in parents:
                item = parents[item];mapped.add(item)
        if any(l['relation'] == 'depends_on' and (l['source'] in mapped or l['target'] in mapped) for l in snapshot['links']):
            raise Invalid('Declared dependencies block independent-event FTA quantification')
        probs = []
        for event_id in event_ids:
            d = by_id[event_id]['data'];p = d.get('probability')
            if type(p) not in (int, float) or not math.isfinite(p) or not 0 <= p <= 1:
                raise Invalid(event_id+': basic-event probability must be finite in [0,1]')
            if d.get('mode') != config['mode'] or type(d.get('mission_hours')) not in (int,float) or d.get('mission_hours') != t:
                raise Invalid(event_id+': probability mode / horizon does not match the FTA')
            for key in ('source', 'conditions', 'dependency_review'):
                if not isinstance(d.get(key), str) or not d[key].strip(): raise Invalid(event_id+': '+key+' required')
            if d.get('dependency_status') != 'reviewed_independent' or any(d.get(k) for k in ('common_cause', 'dependencies', 'standby', 'dynamic', 'conditional_probability')):
                raise Invalid(event_id+': independent static-event review is unresolved or unsupported')
            probs.append(p)
        states = 1 << len(event_ids)
        # One byte per disjoint assignment. Bitwise AND/OR on these vectors
        # evaluates the DAG once, rather than testing every overlapping cut set
        # for every state. Repeated IDs reuse exactly the same truth vector.
        truth = {event: int.from_bytes(bytes((a >> i) & 1 for a in range(states)), 'little')
                 for i,event in enumerate(event_ids)}
        def evaluate(node_id):
            if node_id in truth: return truth[node_id]
            values = [evaluate(i) for i in children[node_id]]
            value = values[0]
            for other in values[1:]:
                value = value & other if by_id[node_id]['data']['logic'] == 'AND' else value | other
            truth[node_id] = value
            return value
        top_truth = evaluate(config['top']).to_bytes(states, 'little')
        # Sum only disjoint assignments, never overlapping cut-set probabilities.
        terms = [math.prod(p if a & (1 << i) else 1-p for i,p in enumerate(probs))
                 for a in range(states) if top_truth[a]]
        probability = math.fsum(terms)
        if probability == 0 and any(all(by_id[i]['data']['probability'] > 0 for i in cut) for cut in cut_sets):
            raise Invalid('Positive top-event probability is below binary64 range; no zero result is retained. Use a qualified higher-precision solver.')
        if not math.isfinite(probability) or not 0 <= probability <= 1+1e-12: raise Invalid('FTA probability arithmetic failed')
        probability = min(1.0, probability)
    nodes = sorted((by_id[i] for i in used), key=lambda e:e['id'])
    links = sorted((l for l in snapshot['links'] if l['relation']=='input_to' and l['source'] in used and l['target'] in used), key=lambda l:(l['source'],l['target']))
    basis = {'engine': ENGINE, 'producer': PRODUCER, 'config': config, 'inputs': nodes, 'links': links}
    return {'engine': ENGINE, 'method': 'static_fta', 'basis': basis, 'basis_sha256': digest(basis),
            'result': {'minimal_cut_sets': [sorted(c) for c in cut_sets], 'top_event_probability': probability,
                       'distinct_basic_events': len(event_ids), 'reachable_nodes': len(used)},
            'warnings': ['Binary64 arithmetic may underflow in extreme probability tails.'] if config['quantify'] else [],
            'applicability': ['Static monotone AND/OR logic only; repeated IDs denote the same event.',
                              'Minimal cut sets are qualitative sufficient combinations, not mutually exclusive outcomes.',
                              'Quantification, when requested, enumerates disjoint assignments of declared independent basic events at one mode and horizon.',
                              'No dynamic gates, sequence dependence, CCF model, conditional dependence, SIL or acceptance claim.']}


def replay(run):
    if run.get('engine') != ENGINE or run.get('basis', {}).get('producer') != PRODUCER:
        raise Invalid('FTA producer differs; restore the original source/runtime or create a new run')
    if digest(run.get('basis')) != run.get('basis_sha256'): raise Invalid('FTA basis identity mismatch')
    fresh = calculate(run['snapshot'], run['basis']['config'])
    if fresh['basis_sha256'] != run['basis_sha256'] or fresh['result'] != run['result']:
        raise Invalid('FTA replay differs from the recorded basis/result')
    return {'run': run['id'], 'matches': True, 'engine': ENGINE, 'producer': PRODUCER,
            'scope': 'Same-producer static FTA replay; not engineering acceptance.'}
