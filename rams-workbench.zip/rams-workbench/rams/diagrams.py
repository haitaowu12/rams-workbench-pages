"""Study-to-presentation adapter; the unified capability owns all drawing/layout."""
from vendor.unified_visuals import unified_engineering as shared
from .engine import Invalid
from .repository import coverage
from copy import deepcopy

FAMILIES = {'fta': ('fault-tree', {'fault_event', 'fault_gate'}, {'input_to'}),
    'bowtie': ('bow-tie', {'hazard', 'cause', 'failure_mode', 'deviation', 'consequence', 'control'}, {'causes', 'prevents', 'mitigates', 'controls'}),
    'rbd': ('rbd', {'item'}, set())}


def review_trace(snapshot, nodes, links, hazard):
    """Bounded hazard/control/requirement/verification excerpts; no new assessment."""
    by_id = {e['id']: e for e in snapshot['entities']}
    if hazard not in by_id or by_id[hazard]['kind'] != 'hazard' or by_id[hazard]['state'] == 'archived':
        raise Invalid('Select an active hazard for its bow-tie trace')
    selected = {n['id'] for n in nodes}
    signatures = {(x['source'], x['relation'], x['target']) for x in links}
    trace_links = [deepcopy(l) for l in snapshot['links']
                   if (l['source'], l['relation'], l['target']) in signatures]
    controls = {n['id'] for n in nodes if n['kind'] == 'control'}
    # Walk the declared directions only. A shared requirement never imports another hazard.
    for relation, targets in [('implements', controls), ('verifies', None)]:
        if targets is None:
            targets = controls | {i for i in selected if by_id[i]['kind'] == 'requirement'}
        for link in snapshot['links']:
            if link['relation'] == relation and link['target'] in targets:
                source = by_id.get(link['source'])
                if source is None:
                    raise Invalid('Unresolved study trace endpoint')
                if source['state'] == 'archived' or by_id[link['target']]['state'] == 'archived':
                    continue
                selected.add(source['id']);trace_links.append(deepcopy(link))
    records = []
    for identity in sorted(selected):
        record = deepcopy(by_id[identity])
        evidence = record['data'].get('evidence_content')
        if isinstance(evidence, dict):
            evidence.pop('base64', None)
        records.append(record)
    try:
        row = next(r for r in coverage(snapshot) if r['hazard'] == hazard)
    except KeyError as error:
        raise Invalid('Unresolved source study link in review trace') from error
    messages = list(row['gaps'])
    messages.append('Recorded decision: ' + row['decision'] + ('; applicability needs review.' if row['decision_needs_review'] else '.'))
    messages.append('Verification results and reviewer names are declarations; evidence adequacy, execution and authenticated approval are not established by this view.')
    return dict(origin={k: snapshot['project'][k] for k in ('id', 'title', 'revision')},
        scope='Selected bow-tie records and incoming implements/verifies links. Other relationships, archived supporting records, attachment bytes, full history and calculations remain in project.json and the study export. Coverage notices come from RAMS Workbench; this reader does not recalculate or approve them.',
        records=records, links=trace_links, notices=[dict(record=hazard, message=m) for m in messages])


def projection(snapshot, kind, subject=None, tree=None):
    """Project declared drawing facts plus bounded read-only bow-tie trace excerpts."""
    family, kinds, relations = FAMILIES[kind]
    nodes = []
    for e in snapshot['entities']:
        if e['kind'] not in kinds:
            continue
        node = {k: e[k] for k in ('id', 'kind', 'title', 'state', 'revision', 'description') if k in e}
        attributes = ('logic',) if e['kind'] == 'fault_gate' else ('status',) if e['kind'] == 'control' else ()
        node['data'] = {k: e['data'][k] for k in attributes if k in e.get('data', {})}
        nodes.append(node)
    links = [{k: link[k] for k in ('source', 'relation', 'target')} for link in snapshot['links']
        if link['relation'] in relations]
    if kind == 'fta':
        selected = {subject}
        for _ in range(81):
            children = {l['source'] for l in links if l['target'] in selected}
            if children <= selected: break
            selected |= children
        nodes = [n for n in nodes if n['id'] in selected]
        links = [l for l in links if l['source'] in selected and l['target'] in selected]
    if kind == 'bowtie':
        causal = [l for l in links if l['relation'] == 'causes' and subject in (l['source'], l['target'])]
        paths = {endpoint for l in causal for endpoint in (l['source'], l['target'])}
        links = causal + [l for l in links if (l['relation'] == 'controls' and l['target'] == subject) or (l['relation'] in ('prevents', 'mitigates') and l['target'] in paths)]
        selected = {subject} | {endpoint for l in links for endpoint in (l['source'], l['target'])}
        nodes = [n for n in nodes if n['id'] in selected]
    name = subject or 'success'
    view = {'profile': shared.PROFILE, 'family': family,
        'id': kind + '-' + name.lower().replace('_', '-'),
        'title': family.replace('-', ' ').title() + ' · ' + name,
        'note': 'Engineering presentation of declared study records. Calculations, evidence adequacy and acceptance remain in the source study.',
        'revision': snapshot['project']['revision'], 'nodes': nodes, 'links': links}
    if kind == 'rbd': view['topology'] = tree
    else: view['subject'] = subject
    if kind == 'bowtie':
        view['trace'] = review_trace(snapshot, nodes, links, subject)
    return view


def render(snapshot, kind, subject=None, tree=None):
    try:
        return shared.render(projection(snapshot, kind, subject, tree))
    except shared.DiagramError as error:
        raise Invalid(str(error)) from error


def bowtie(snapshot, hazard_id):
    result = render(snapshot, 'bowtie', hazard_id)
    return result['svg'], set(result['allocated'])


def fault_tree(snapshot, top):
    return render(snapshot, 'fta', top)['svg']


def rbd(snapshot, tree):
    return render(snapshot, 'rbd', tree=tree)['svg']
