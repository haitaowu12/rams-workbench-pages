"""Consistent local workspace backups and non-destructive restore to a new path."""
import argparse
import os
import json
from pathlib import Path
import sqlite3
import tempfile
from .engine import Invalid

COLUMNS = {
    'projects': ['id', 'title', 'revision', 'config'],
    'entities': ['project', 'id', 'kind', 'body'],
    'links': ['project', 'source', 'relation', 'target', 'body'],
    'history': ['project', 'revision', 'at', 'actor', 'payload'],
    'baselines': ['id', 'project', 'label', 'at', 'body'],
    'runs': ['id', 'project', 'revision', 'at', 'body'],
}


def inspect_connection(db):
    db.execute('PRAGMA trusted_schema=OFF')
    if db.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
        raise Invalid('SQLite integrity check failed')
    if db.execute('PRAGMA foreign_key_check').fetchall():
        raise Invalid('Workspace has broken foreign keys')
    if db.execute('PRAGMA user_version').fetchone()[0] != 0:
        raise Invalid('Unsupported workspace schema version')
    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if tables != set(COLUMNS) or db.execute("SELECT 1 FROM sqlite_master WHERE type IN ('trigger','view')").fetchone():
        raise Invalid('Unrecognized workspace schema')
    for table, columns in COLUMNS.items():
        if [r[1] for r in db.execute(f'PRAGMA table_info({table})')] != columns:
            raise Invalid('Unsupported workspace columns: ' + table)
    return {table: db.execute(f'SELECT count(*) FROM {table}').fetchone()[0] for table in COLUMNS}


def readonly(path):
    path = Path(path).resolve(strict=True)
    return sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)


def snapshot_bytes(source):
    # The SQLite backup API includes committed WAL content and pins a consistent snapshot.
    with tempfile.TemporaryDirectory(prefix='rams-backup-') as temp:
        target = Path(temp) / 'workspace.sqlite3'
        src = readonly(source)
        try:
            src.execute('PRAGMA trusted_schema=OFF')
            dest = sqlite3.connect(target)
            try:
                src.backup(dest)
                inspect_connection(dest)
                dest.commit()
            finally:
                dest.close()
        finally:
            src.close()
        return target.read_bytes()


def copy_workspace(source, destination):
    destination = Path(destination).expanduser()
    if destination.exists():
        raise Invalid('Destination already exists. Choose a new path; existing workspaces are never overwritten.')
    body = snapshot_bytes(source)
    # Exclusive creation also refuses a race or a symlink at the destination.
    with os.fdopen(os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb') as stream:
        try:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            stream.close()
            destination.unlink(missing_ok=True)
            raise
    destination.chmod(0o600)
    db = readonly(destination)
    try:
        return {'path': str(destination.resolve()), 'counts': inspect_connection(db), 'bytes':len(body)}
    finally:
        db.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for command in ('backup', 'restore'):
        p = sub.add_parser(command)
        p.add_argument('source', type=Path)
        p.add_argument('destination', type=Path)
    p = sub.add_parser('inspect'); p.add_argument('source', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'inspect':
            db = readonly(args.source)
            try: result = inspect_connection(db)
            finally: db.close()
        else: result = copy_workspace(args.source, args.destination)
        print(json.dumps(result, indent=2))
    except (OSError, sqlite3.Error, Invalid) as error:
        parser.exit(1, f'Workspace operation refused: {error}\n')

if __name__ == '__main__': main()
