"""Shared local/browser request service; numerical and repository contracts stay in their owners."""
from dataclasses import dataclass
from pathlib import Path
import io,zipfile
from . import VERSION
from .engine import PRODUCER as RBD_PRODUCER, Invalid, canonical
from .fault_tree import PRODUCER as FTA_PRODUCER
from .repository import KINDS, STATES, RELATIONS, coverage, requirement_coverage, preview_import, csv_register, sysml_projection, Conflict
from .diagrams import bowtie, fault_tree, rbd
from .technical_review import review, traceability, related_records
from .insights import importance
ROOT=Path(__file__).resolve().parents[1]

@dataclass
class Reply:
    value: object
    status: int = 200
    content_type: str = 'application/json; charset=utf-8'
    filename: str | None = None

    def bytes(self):
        return self.value if isinstance(self.value,bytes) else (self.value.encode() if isinstance(self.value,str) else canonical(self.value).encode())

def bundle(archive):
    snapshot = archive['snapshot']
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as z:
        from rams.study_output import portable_html
        z.writestr('study.html', portable_html(archive))
        z.writestr('project.json', canonical(snapshot))
        z.writestr('history.json', canonical(archive['history']))
        z.writestr('README.txt', 'Local study export. project.json reopens as a new project. History, baselines and runs remain historical files; importing project.json does not restore their database identities. Not a signed approval record.\n')
        projection = sysml_projection(snapshot)
        z.writestr('model.sysml', projection['sysml'])
        z.writestr('projection.json', canonical(projection['projection']))
        z.writestr('register.csv', csv_register(snapshot))
        from rams.diagrams import bowtie, fault_tree, rbd, projection
        diagram_index = []
        for e in snapshot['entities']:
            if e['state'] == 'archived' or e['kind'] not in ('hazard', 'fault_gate'): continue
            method = 'bowtie' if e['kind'] == 'hazard' else 'fta'
            try:
                drawing = bowtie(snapshot, e['id'])[0] if method == 'bowtie' else fault_tree(snapshot, e['id'])
                path = f"diagrams/{method}-{e['id']}.svg"
                z.writestr(path, drawing)
                source_path = path[:-4] + '.json'
                z.writestr(source_path, canonical(projection(snapshot, 'fta' if method == 'fta' else 'bowtie', e['id'])))
                diagram_index.append({'source': source_path, 'method': method, 'record': e['id'], 'file': path, 'scope': 'Qualitative graphical view; not a calculated or approved result'})
            except Invalid as error:
                diagram_index.append({'method': method, 'record': e['id'], 'blocked': str(error)})
        for run_record in archive['runs']:
            run = run_record['body']
            if run.get('method') == 'static_fta': continue
            try:
                drawing = rbd(run['snapshot'], run['basis']['config']['tree'])
                path = f"diagrams/rbd-{run['id']}.svg"
                z.writestr(path, drawing)
                source_path = path[:-4] + '.json'
                z.writestr(source_path, canonical(projection(run['snapshot'], 'rbd', tree=run['basis']['config']['tree'])))
                diagram_index.append({'source': source_path, 'method': 'rbd', 'run': run['id'], 'file': path, 'scope': 'Exact retained run topology; probabilities remain in run JSON'})
            except (Invalid, KeyError) as error:
                diagram_index.append({'method': 'rbd', 'run': run.get('id'), 'blocked': str(error)})
        z.writestr('diagrams/index.json', canonical(diagram_index))
        for kind in ('runs', 'baselines'):
            for r in archive[kind]:
                z.writestr(f'{kind}/{r["id"]}.json', canonical(r['body']))
    return stream.getvalue()


def dispatch(repo,method,path,q=None,data=None,health=None):
    q=q or {};data=data or {};project=q.get('project',[''])[0]
    if method=='GET':
        if path=='/api/health': return Reply(dict(status='ok',version=VERSION,projects=len(repo.projects()),**(health or {})))
        if path=='/api/info':return Reply(dict(version=VERSION,kinds=KINDS,states=STATES,relations=list(RELATIONS),producers=dict(rbd=RBD_PRODUCER,fta=FTA_PRODUCER)))
        if path=='/api/workspace-backup':
            from .storage import snapshot_bytes
            return Reply(snapshot_bytes(repo.path),content_type='application/vnd.sqlite3',filename='rams-workspace.sqlite3')
        if path=='/api/projects':return Reply(repo.projects())
        if path=='/api/project':
            snap=repo.get(project)
            return Reply({**snap,'coverage':coverage(snap),'requirement_coverage':requirement_coverage(snap)})
        if path=='/api/technical-review':return Reply(review(repo.get(project)))
        if path=='/api/traceability':return Reply(traceability(repo.get(project)))
        if path=='/api/related-records':return Reply(related_records(repo.get(project),q.get('record',[''])[0]))
        if path=='/api/importance':return Reply(importance(repo.record(project,'runs',q.get('run',[''])[0])))
        if path=='/api/records':return Reply(repo.records(project))
        if path=='/api/record':return Reply(repo.record(project,q.get('kind',[''])[0],q.get('id',[''])[0]))
        if path=='/api/diagram':
            snap=repo.get(project);kind=q.get('kind',[''])[0];record=q.get('record',[''])[0]
            if kind=='bowtie':drawing=bowtie(snap,record)[0]
            elif kind=='fta':drawing=fault_tree(snap,record)
            else:raise Invalid('Unknown engineering diagram kind')
            return Reply(dict(svg=drawing))
        if path=='/api/run-diagram':
            run=repo.record(project,'runs',q.get('run',[''])[0])
            return Reply(dict(svg=rbd(run['snapshot'],run['basis']['config']['tree'])))
        if path=='/api/study-html':
            from .study_output import portable_html
            return Reply(portable_html(repo.archive(project)),content_type='text/html; charset=utf-8',filename='study.html')
        if path=='/api/export':return Reply(bundle(repo.archive(project)),content_type='application/zip',filename='rams-study.zip')
        if path in ('/api/method-example','/api/example'):
            name='analysis-methods.json' if path=='/api/method-example' else 'synthetic-station.json'
            return Reply((ROOT/'examples'/name).read_bytes())
    elif method=='POST':
        if path=='/api/import-preview':return Reply(preview_import(data.get('snapshot')))
        if path=='/api/complete-example':
            from .examples import complete_study
            return Reply(complete_study(repo),201)
        if path=='/api/create':return Reply(repo.create(data.get('title'),data.get('snapshot')),201)
        if path=='/api/mutate':return Reply(repo.mutate(data.get('project'),data.get('expected'),data.get('operation')))
        if path=='/api/baseline':return Reply(repo.baseline(data.get('project'),data.get('expected'),data.get('label')),201)
        if path=='/api/rbd-diagram':
            snap=repo.get(data.get('project'))
            if snap['project']['revision']!=data.get('expected'):raise Conflict('RBD drawing basis is stale')
            return Reply(dict(svg=rbd(snap,data.get('tree')),revision=snap['project']['revision']))
        if path=='/api/fault-tree':return Reply(repo.analyze_fault_tree(data.get('project'),data.get('expected'),data.get('config')),201)
        if path=='/api/analyze':return Reply(repo.analyze(data.get('project'),data.get('expected'),data.get('config')),201)
    return Reply(dict(error='Not found'),404)
