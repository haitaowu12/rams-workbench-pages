"""RAMS Workbench: browser and local engineering study application."""
VERSION = '0.3.0-dev2'
