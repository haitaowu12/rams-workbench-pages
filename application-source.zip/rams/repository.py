"""Transactional local study repository with optimistic concurrency and snapshots."""
from datetime import datetime, timezone
from contextlib import contextmanager
import base64
import hashlib
import binascii
import csv
import io
import json
from pathlib import Path
import re
import sqlite3
import uuid
from .engine import Invalid, canonical, calculate, digest

KINDS = ('item', 'part_type', 'operating_mode', 'function', 'interface', 'hazard', 'cause', 'consequence', 'control', 'requirement',
         'verification', 'assumption', 'action', 'srac', 'study_node', 'deviation', 'failure_mode', 'fault_event', 'fault_gate')
RELATIONS = {
    'analyzes': ({'fault_gate'}, {'hazard', 'failure_mode'}),
    'input_to': ({'fault_event', 'fault_gate'}, {'fault_gate'}),
    'prevents': ({'control'}, {'cause'}),
    'mitigates': ({'control'}, {'consequence'}),
    'contains': ({'item'}, {'item'}),
    'instance_of': ({'item'}, {'part_type'}),
    'operates_in': (set(KINDS)-{'operating_mode'}, {'operating_mode'}),
    'applies_to': (set(KINDS)-{'item'}, {'item', 'function', 'interface'}),
    'causes': ({'cause', 'failure_mode', 'deviation', 'hazard'}, {'hazard', 'consequence'}),
    'controls': ({'control'}, {'hazard'}),
    'implements': ({'requirement'}, {'control'}),
    'verifies': ({'verification'}, {'requirement', 'control'}),
    'depends_on': (set(KINDS), set(KINDS)),
    'addresses': ({'action', 'srac', 'assumption'}, set(KINDS)),
    'studies': ({'study_node'}, {'item', 'function', 'interface'}),
    'deviates': ({'deviation'}, {'study_node'}),
    'fails': ({'failure_mode'}, {'item', 'function'}),
}
STATES = ('draft', 'in_review', 'reviewed', 'archived')
ID = re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,79}$')


def now():
    return datetime.now(timezone.utc).isoformat()


def text(v, label, limit=10000):
    if not isinstance(v, str) or not v.strip() or len(v) > limit:
        raise Invalid(f'{label} must be nonempty text (maximum {limit} characters)')
    return v


def validate_config(config):
    if not isinstance(config, dict):
        raise Invalid('Project configuration must be an object')
    for key in ('system_boundary', 'configuration', 'lifecycle_phase', 'governing_basis', 'operating_context', 'acceptance_process'):
        if key in config and (not isinstance(config[key], str) or len(config[key]) > 10000):
            raise Invalid(key + ' must be text of at most 10,000 characters')
    matrix = config.get('risk_matrix')
    if matrix is None: return
    if not isinstance(matrix, dict): raise Invalid('Risk matrix must be an object')
    for key in ('id', 'revision', 'source'):
        text(matrix.get(key), 'Risk matrix '+key, 1000)
    for key in ('severity_classes', 'frequency_classes'):
        classes = matrix.get(key)
        if not isinstance(classes, list) or not classes or not all(isinstance(v, str) and v.strip() for v in classes) or len(set(classes)) != len(classes):
            raise Invalid('Risk matrix classes must be unique nonempty strings')
    if not isinstance(matrix.get('cells'), list): raise Invalid('Risk matrix cells must be a list')
    seen = set()
    for cell in matrix['cells']:
        if not isinstance(cell, dict) or set(cell) != {'severity', 'frequency', 'category'}:
            raise Invalid('Risk matrix cells need severity, frequency and category')
        if cell['severity'] not in matrix['severity_classes'] or cell['frequency'] not in matrix['frequency_classes']:
            raise Invalid('Risk matrix cell has an unknown class')
        text(cell['category'], 'Risk category', 200)
        key = (cell['severity'], cell['frequency'])
        if key in seen: raise Invalid('Duplicate risk matrix cell')
        seen.add(key)


def engineering_digest(snapshot):
    """Conservative engineering identity excluding review acknowledgements."""
    entities = []
    for e in snapshot['entities']:
        d = {k: v for k, v in e['data'].items() if k not in
             ('decision', 'decision_project_revision', 'decision_project_id', 'decision_engineering_sha256')}
        entities.append({'id': e['id'], 'kind': e['kind'], 'title': e['title'], 'description': e['description'],
                         'archived': e['state'] == 'archived', 'data': d})
    return digest({'entities': sorted(entities, key=lambda e: e['id']),
                   'links': sorted(snapshot['links'], key=lambda l: (l['source'], l['relation'], l['target'])),
                   'config': snapshot['project']['config']})


def validate_entities(entities, links):
    if not isinstance(entities, list) or not isinstance(links, list) or len(entities) > 10000 or len(links) > 50000:
        raise Invalid('Project limit: 10,000 entities / 50,000 relationships')
    by_id = {}
    for e in entities:
        if not isinstance(e, dict) or set(e) != {'id', 'kind', 'title', 'description', 'state', 'data', 'revision'}:
            raise Invalid('Entity fields must be id, kind, title, description, state, data, revision')
        if not isinstance(e['id'], str) or not ID.fullmatch(e['id']) or e['id'] in by_id:
            raise Invalid('Entity IDs must be unique stable identifiers beginning with a letter')
        if e['kind'] not in KINDS or e['state'] not in STATES:
            raise Invalid('Invalid entity kind or state')
        text(e['title'], 'Title', 500)
        if not isinstance(e['description'], str) or len(e['description']) > 50000 or not isinstance(e['data'], dict):
            raise Invalid('Description must be text; data must be an object')
        if type(e['revision']) is not int or e['revision'] < 1:
            raise Invalid('Entity revision must be a positive integer')
        if len(canonical(e['data'])) > 100000:
            raise Invalid('Entity data exceeds 100,000 characters')
        if e['kind'] == 'deviation' and 'examination' in e['data'] and e['data']['examination'] not in ('finding', 'no_issue', 'deferred', 'not_applicable'):
            raise Invalid('HAZOP examination must be finding, no_issue, deferred or not_applicable')
        if e['kind'] == 'requirement' and 'obligations' in e['data']:
            obligations = e['data']['obligations']
            if not isinstance(obligations, list) or len(obligations) > 100:
                raise Invalid('Requirement obligations must be a list of at most 100 entries')
            seen_obligations = set()
            for obligation in obligations:
                if not isinstance(obligation, dict) or set(obligation) != {'id', 'mode', 'configuration'}:
                    raise Invalid('Each obligation needs id, mode and configuration')
                for key in ('id', 'mode', 'configuration'): text(obligation[key], 'Obligation '+key, 1000)
                if obligation['id'] in seen_obligations: raise Invalid('Duplicate obligation ID')
                seen_obligations.add(obligation['id'])
        if e['kind'] == 'verification' and 'evidence_content' in e['data']:
            evidence = e['data']['evidence_content']
            if not isinstance(evidence, dict) or set(evidence) != {'name', 'media_type', 'sha256', 'base64'}:
                raise Invalid('Evidence content requires name, media_type, sha256 and base64')
            text(evidence['name'], 'Evidence filename', 500)
            text(evidence['media_type'], 'Evidence media type', 200)
            try:
                content = base64.b64decode(evidence['base64'], validate=True)
            except (ValueError, TypeError, binascii.Error):
                raise Invalid('Evidence content must be valid base64') from None
            if len(content) > 32768: raise Invalid('Retained evidence limit is 32 KiB per record')
            if hashlib.sha256(content).hexdigest() != evidence['sha256']:
                raise Invalid('Evidence content SHA-256 mismatch')
        # Reviewed is a study workflow label. Acceptance is a separate recorded declaration.
        if e['kind'] == 'hazard' and 'decision' in e['data']:
            d = e['data']['decision']
            if not isinstance(d, dict) or d.get('outcome') not in ('pending', 'accepted', 'rejected', 'conditional'):
                raise Invalid('Decision outcome must be pending, accepted, rejected or conditional')
            if d['outcome'] != 'pending':
                for k in ('authority', 'rationale', 'date', 'basis_revision', 'evidence'):
                    if k == 'basis_revision':
                        if type(d.get(k)) is not int or not 1 <= d[k] <= e['revision']:
                            raise Invalid('Decision basis_revision must name an existing entity revision')
                    else:
                        text(d.get(k), f'Decision {k}')
        by_id[e['id']] = e
    unique = set()
    parents = {}
    for link in links:
        if not isinstance(link, dict) or set(link) != {'source', 'relation', 'target', 'rationale'}:
            raise Invalid('Relationship fields must be source, relation, target, rationale')
        s, r, t = (link[k] for k in ('source', 'relation', 'target'))
        if not all(isinstance(x, str) for x in (s, r, t)) or s not in by_id or t not in by_id or s == t or r not in RELATIONS:
            raise Invalid('Relationship has a missing endpoint, self-link or unknown type')
        if by_id[s]['kind'] not in RELATIONS[r][0] or by_id[t]['kind'] not in RELATIONS[r][1]:
            raise Invalid(f'Invalid {r} endpoint kinds')
        text(link['rationale'], 'Relationship rationale')
        key = (s, r, t)
        if key in unique:
            raise Invalid('Duplicate relationship')
        unique.add(key)
        if r == 'contains':
            if t in parents:
                raise Invalid('An instance has only one containment parent; use depends_on for shared support')
            parents[t] = s
    for child in parents:
        seen = set()
        current = child
        while current in parents:
            if current in seen:
                raise Invalid('Containment cycle')
            seen.add(current)
            current = parents[current]
            if len(seen) > 100:
                raise Invalid('Containment depth exceeds 100')


class Conflict(Invalid):
    pass


class Repository:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
              PRAGMA journal_mode=WAL;
              CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, title TEXT NOT NULL, revision INTEGER NOT NULL, config TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS entities(project TEXT NOT NULL REFERENCES projects(id), id TEXT NOT NULL, kind TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(project,id));
              CREATE INDEX IF NOT EXISTS entities_kind ON entities(project,kind,id);
              CREATE TABLE IF NOT EXISTS links(project TEXT NOT NULL REFERENCES projects(id), source TEXT NOT NULL, relation TEXT NOT NULL, target TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(project,source,relation,target));
              CREATE INDEX IF NOT EXISTS links_target ON links(project,target);
              CREATE TABLE IF NOT EXISTS history(project TEXT NOT NULL REFERENCES projects(id), revision INTEGER NOT NULL, at TEXT NOT NULL, actor TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(project,revision));
              CREATE TABLE IF NOT EXISTS baselines(id TEXT PRIMARY KEY, project TEXT NOT NULL REFERENCES projects(id), label TEXT NOT NULL, at TEXT NOT NULL, body TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, project TEXT NOT NULL REFERENCES projects(id), revision INTEGER NOT NULL, at TEXT NOT NULL, body TEXT NOT NULL);
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def projects(self):
        with self.connect() as db:
            return [dict(r) for r in db.execute('SELECT id,title,revision FROM projects ORDER BY title,id')]

    def create(self, title, source=None):
        text(title, 'Project title', 500)
        project = 'P' + uuid.uuid4().hex
        config = {'profile': 'generic', 'governing_standards': [], 'operating_context': '', 'acceptance_process': ''}
        entities, links = [], []
        if source is not None:
            preview_import(source)
            entities, links = source.get('entities'), source.get('links')
            config = source.get('project', {}).get('config')
            # New local identity; preserve the complete imported snapshot as lineage.
            config = {**config, 'import_lineage': source}
        validate_config(config)
        with self.connect() as db:
            db.execute('INSERT INTO projects VALUES(?,?,1,?)', (project, title, canonical(config)))
            for e in entities:
                db.execute('INSERT INTO entities VALUES(?,?,?,?)', (project, e['id'], e['kind'], canonical(e)))
            for l in links:
                db.execute('INSERT INTO links VALUES(?,?,?,?,?)', (project, l['source'], l['relation'], l['target'], canonical(l)))
            db.execute('INSERT INTO history VALUES(?,?,?,?,?)', (project, 1, now(), 'local-user', canonical({'create': title, 'imported': source is not None})))
        return self.get(project)

    def _get(self, db, project):
        row = db.execute('SELECT * FROM projects WHERE id=?', (project,)).fetchone()
        if row is None:
            raise Invalid('Project not found')
        p = dict(row)
        p['config'] = json.loads(p['config'])
        return {'format': 'rams-workbench/1', 'project': p,
                'entities': [json.loads(r[0]) for r in db.execute('SELECT body FROM entities WHERE project=? ORDER BY id', (project,))],
                'links': [json.loads(r[0]) for r in db.execute('SELECT body FROM links WHERE project=? ORDER BY source,relation,target', (project,))]}

    def get(self, project):
        with self.connect() as db:
            db.execute('BEGIN')
            return self._get(db, project)

    def mutate(self, project, expected, operation, actor='local-user'):
        text(actor, 'Actor', 200)
        if type(expected) is not int or not isinstance(operation, dict):
            raise Invalid('Expected project revision and operation required')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            snap = self._get(db, project)
            if snap['project']['revision'] != expected:
                raise Conflict('Project changed in another window. Your draft is retained; reload and reconcile it.')
            entities, links = snap['entities'], snap['links']
            if set(operation) == {'entity'}:
                e = operation['entity']
                if not isinstance(e, dict):
                    raise Invalid('Entity must be an object')
                old = next((x for x in entities if x['id'] == e.get('id')), None)
                if old and e.get('kind') != old['kind']:
                    raise Invalid('Entity kind is immutable; create another ID')
                e = {**e, 'revision': old['revision'] + 1 if old else 1}
                entities = [x for x in entities if x['id'] != e.get('id')] + [e]
                validate_entities(entities, links)
                if e['kind'] == 'hazard':
                    current_decision = e['data'].get('decision')
                    previous_decision = old['data'].get('decision') if old else None
                    metadata = ('decision_project_revision', 'decision_project_id', 'decision_engineering_sha256')
                    for k in metadata: e['data'].pop(k, None)
                    if isinstance(current_decision, dict) and current_decision.get('outcome') != 'pending':
                        if current_decision != previous_decision:
                            e['data'].update(decision_project_revision=expected+1, decision_project_id=project,
                                             decision_engineering_sha256=engineering_digest({**snap, 'entities': entities}))
                        elif old:
                            for k in metadata:
                                if k in old['data']: e['data'][k] = old['data'][k]
                db.execute('INSERT OR REPLACE INTO entities VALUES(?,?,?,?)', (project, e['id'], e['kind'], canonical(e)))
            elif set(operation) == {'create_entity'}:
                e = operation['create_entity']
                if not isinstance(e, dict) or any(x['id'] == e.get('id') for x in entities):
                    raise Invalid('New record ID already exists; choose another stable ID')
                e = {**e, 'revision': 1}
                validate_entities(entities + [e], links)
                if e['kind'] == 'hazard' and e['data'].get('decision', {}).get('outcome', 'pending') != 'pending':
                    raise Invalid('Create the hazard before recording a decision')
                db.execute('INSERT INTO entities VALUES(?,?,?,?)', (project, e['id'], e['kind'], canonical(e)))
            elif set(operation) == {'related'}:
                related = operation['related']
                if not isinstance(related, dict) or set(related) != {'entity', 'link'}:
                    raise Invalid('Related creation requires one new entity and one typed link')
                e, l = related['entity'], related['link']
                if not isinstance(e, dict) or any(x['id'] == e.get('id') for x in entities):
                    raise Invalid('Related creation requires a new stable entity ID')
                e = {**e, 'revision': 1}
                validate_entities(entities + [e], links)
                if e.get('kind') == 'hazard' and e.get('data', {}).get('decision', {}).get('outcome', 'pending') != 'pending':
                    raise Invalid('Create the hazard before recording a decision')
                if not isinstance(l, dict) or e.get('id') not in (l.get('source'), l.get('target')):
                    raise Invalid('The relationship must connect the new entity')
                validate_entities(entities + [e], links + [l])
                db.execute('INSERT INTO entities VALUES(?,?,?,?)', (project, e['id'], e['kind'], canonical(e)))
                db.execute('INSERT INTO links VALUES(?,?,?,?,?)', (project, l['source'], l['relation'], l['target'], canonical(l)))
            elif set(operation) == {'link'}:
                l = operation['link']
                validate_entities(entities, links + [l])
                db.execute('INSERT INTO links VALUES(?,?,?,?,?)', (project, l['source'], l['relation'], l['target'], canonical(l)))
            elif set(operation) == {'remove_link'}:
                l = operation['remove_link']
                if not isinstance(l, dict) or set(l) != {'source', 'relation', 'target'}:
                    raise Invalid('Relationship removal requires exact source/relation/target')
                if not db.execute('DELETE FROM links WHERE project=? AND source=? AND relation=? AND target=?',
                                  (project, l['source'], l['relation'], l['target'])).rowcount:
                    raise Invalid('Relationship no longer exists')
            elif set(operation) == {'config'}:
                if 'import_lineage' in snap['project']['config'] and (operation['config'].get('import_lineage') if isinstance(operation['config'], dict) else None) != snap['project']['config']['import_lineage']:
                    raise Invalid('Imported provenance is read only; retain the original lineage')
                validate_config(operation['config'])
                db.execute('UPDATE projects SET config=? WHERE id=?', (canonical(operation['config']), project))
            else:
                raise Invalid('Expected one entity, related, link, remove_link or config operation')
            db.execute('UPDATE projects SET revision=revision+1 WHERE id=?', (project,))
            db.execute('INSERT INTO history VALUES(?,?,?,?,?)', (project, expected+1, now(), actor, canonical(operation)))
            return self._get(db, project)

    def baseline(self, project, expected, label):
        text(label, 'Baseline label', 500)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            snapshot = self._get(db, project)
            if snapshot['project']['revision'] != expected:
                raise Conflict('Baseline request is stale')
            result = {'id': 'B'+uuid.uuid4().hex, 'label': label, 'at': now(), 'snapshot': snapshot}
            db.execute('INSERT INTO baselines VALUES(?,?,?,?,?)', (result['id'], project, label, result['at'], canonical(snapshot)))
            return result

    def analyze(self, project, expected, config):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            snap = self._get(db, project)
            if snap['project']['revision'] != expected:
                raise Conflict('Analysis request is stale')
            # Fail closed if a declared dependency crosses the calculation boundary.
            ids = set()
            def leaves(node, depth=0):
                if depth > 24 or not isinstance(node, dict):
                    raise Invalid('Invalid analysis tree')
                if 'item' in node:
                    if isinstance(node['item'], str): ids.add(node['item'])
                elif isinstance(node.get('children'), list):
                    for c in node['children']: leaves(c, depth+1)
            leaves(config.get('tree') if isinstance(config, dict) else None)
            # Dependencies declared on containing systems apply to selected descendants too.
            parents = {l['target']: l['source'] for l in snap['links'] if l['relation'] == 'contains'}
            for item_id in list(ids):
                current = item_id
                while current in parents:
                    current = parents[current]
                    ids.add(current)
            if any(l['relation'] == 'depends_on' and (l['source'] in ids or l['target'] in ids) for l in snap['links']):
                raise Invalid('Selected items have declared dependencies. Independent RBD evaluation is blocked.')
            result = calculate(snap['entities'], config)
            run = {'id': 'R'+uuid.uuid4().hex, 'at': now(), 'project_id': project,
                   'project_revision': expected, 'snapshot': snap, **result}
            db.execute('INSERT INTO runs VALUES(?,?,?,?,?)', (run['id'], project, expected, run['at'], canonical(run)))
            return run

    def analyze_fault_tree(self, project, expected, config):
        from .fault_tree import calculate as calculate_fta
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            snap = self._get(db, project)
            if type(expected) is not int or snap['project']['revision'] != expected:
                raise Conflict('FTA request is stale; reload and review the basis')
            result = calculate_fta(snap, config)
            run = {'id': 'R'+uuid.uuid4().hex, 'at': now(), 'project': project,
                   'project_revision': expected, 'snapshot': snap, **result}
            db.execute('INSERT INTO runs VALUES(?,?,?,?,?)', (run['id'], project, expected, run['at'], canonical(run)))
            return run

    def records(self, project):
        with self.connect() as db:
            self._get(db, project)
            return {
                'history': [dict(r) for r in db.execute('SELECT revision,at,actor,payload FROM history WHERE project=? ORDER BY revision DESC', (project,))],
                'baselines': [dict(r) for r in db.execute('SELECT id,label,at FROM baselines WHERE project=? ORDER BY at DESC', (project,))],
                'runs': [self._run_summary(r) for r in db.execute('SELECT id,revision,at,body FROM runs WHERE project=? ORDER BY at DESC', (project,))]}

    @staticmethod
    def _run_summary(row):
        from .study_output import run_summary
        return run_summary(json.loads(row['body']))

    def record(self, project, kind, record_id):
        if kind not in ('runs', 'baselines'):
            raise Invalid('Unknown record kind')
        with self.connect() as db:
            r = db.execute(f'SELECT body FROM {kind} WHERE project=? AND id=?', (project, record_id)).fetchone()
            if not r: raise Invalid('Record not found')
            return json.loads(r[0])

    def archive(self, project):
        with self.connect() as db:
            db.execute('BEGIN')
            snap = self._get(db, project)
            result = {'snapshot': snap, 'history': [dict(r) for r in db.execute('SELECT revision,at,actor,payload FROM history WHERE project=? ORDER BY revision', (project,))]}
            result['baseline_metadata'] = [dict(r) for r in db.execute('SELECT id,label,at FROM baselines WHERE project=? ORDER BY at DESC', (project,))]
            for kind in ('baselines', 'runs'):
                result[kind] = [{'id': r['id'], 'body': json.loads(r['body'])} for r in db.execute(f'SELECT id,body FROM {kind} WHERE project=? ORDER BY at', (project,))]
            return result


def verification_complete(data):
    return data.get('result') == 'pass' and all(
        isinstance(data.get(k), str) and data[k].strip()
        for k in ('artifact', 'artifact_revision', 'configuration', 'applicability', 'reviewer'))


def requirement_coverage(snap):
    """Declaration coverage for every active requirement, including unallocated ones.

    This checks metadata/applicability only; it never certifies evidence adequacy.
    """
    active = {e['id']: e for e in snap['entities'] if e['state'] != 'archived'}
    rows = []
    for req in active.values():
        if req['kind'] != 'requirement':
            continue
        verifications = [active[l['source']] for l in snap['links']
                         if l['relation'] == 'verifies' and l['target'] == req['id'] and l['source'] in active]
        obligations = req['data'].get('obligations', [])
        for obligation in obligations or [None]:
            matching = [v for v in verifications if obligation is None or (
                all(v['data'].get(k) == obligation[k] for k in ('mode', 'configuration')) and
                v['data'].get('obligation') == obligation['id'] and
                v['data'].get('requirement_revision') == req['revision'])]
            passing = [v['id'] for v in matching if verification_complete(v['data'])]
            rows.append({'requirement': req['id'], 'revision': req['revision'], 'obligation': obligation,
                         'verifications': [v['id'] for v in verifications], 'passing': passing,
                         'status': ('covered' if passing else 'gap') if obligation else
                                   ('legacy_declaration' if passing else 'gap'),
                         'incomplete': [v['id'] for v in verifications if not verification_complete(v['data'])]})
    return rows


def preview_import(source):
    """Validate with the creation contract without opening a write transaction."""
    if not isinstance(source, dict) or source.get('format') != 'rams-workbench/1':
        raise Invalid('Expected rams-workbench/1 project snapshot (project.json from the full archive)')
    if set(source) - {'format', 'project', 'entities', 'links', 'lineage', 'limitations'}:
        raise Invalid('Unknown project snapshot fields')
    project = source.get('project')
    if not isinstance(project, dict):
        raise Invalid('Imported project must be an object')
    text(project.get('title'), 'Imported project title', 500)
    validate_entities(source.get('entities'), source.get('links'))
    validate_config(project.get('config'))
    counts = {}
    for e in source['entities']:
        counts[e['kind']] = counts.get(e['kind'], 0) + 1
    return {'title': project['title'], 'source_id': project.get('id'), 'revision': project.get('revision'),
            'records': len(source['entities']), 'relationships': len(source['links']), 'kinds': counts,
            'archived': sum(e['state'] == 'archived' for e in source['entities']),
            'decisions_for_review': sum(e['kind'] == 'hazard' and e['state'] != 'archived' and
                e['data'].get('decision', {}).get('outcome', 'pending') != 'pending' for e in source['entities'])}


def coverage(snap):
    entities, links = snap['entities'], snap['links']
    by_id = {e['id']: e for e in entities}
    rows = []
    active = lambda i: by_id[i]['state'] != 'archived'
    engineering_sha = engineering_digest(snap)
    incoming = {}
    for l in links:
        if active(l['source']) and active(l['target']):
            incoming.setdefault((l['relation'], l['target']), []).append(l['source'])
    for h in entities:
        if h['kind'] != 'hazard' or h['state'] == 'archived': continue
        controls = sorted(set(incoming.get(('controls', h['id']), [])))
        requirements = sorted({r for c in controls for r in incoming.get(('implements', c), [])})
        verifications = sorted({v for r in requirements for v in incoming.get(('verifies', r), [])})
        decision = h['data'].get('decision', {'outcome': 'pending'})
        # Every change conservatively requires renewed decision applicability review.
        stale = decision.get('outcome') != 'pending' and (h['data'].get('decision_engineering_sha256') != engineering_sha or h['data'].get('decision_project_id') != snap['project']['id'])
        gaps = []
        if not controls: gaps.append('No controls')
        for c in controls:
            reqs = incoming.get(('implements', c), [])
            if not reqs: gaps.append(f'{c}: no implementing requirement')
        for req in requirements:
            vs = incoming.get(('verifies', req), [])
            if not vs: gaps.append(f'{req}: no verification')
            for v in vs:
                data = by_id[v]['data']
                if not verification_complete(data):
                    gaps.append(f'{req}/{v}: result, artifact or applicability incomplete')
            for obligation in by_id[req]['data'].get('obligations', []):
                matching = [by_id[v]['data'] for v in vs if
                            by_id[v]['data'].get('obligation') == obligation['id'] and
                            by_id[v]['data'].get('mode') == obligation['mode'] and
                            by_id[v]['data'].get('configuration') == obligation['configuration'] and
                            by_id[v]['data'].get('requirement_revision') == by_id[req]['revision']]
                if not any(verification_complete(d) for d in matching):
                    gaps.append(f"{req}/{obligation['id']}: no passing declaration for current requirement revision, mode and configuration")
        if not h['data'].get('mode') or not h['data'].get('boundary'): gaps.append('Operating mode or system boundary missing')
        def risk(stage):
            point = h['data'].get(stage, {})
            matrix = snap['project']['config'].get('risk_matrix', {})
            if not isinstance(point, dict) or not isinstance(matrix, dict): return 'unassessed'
            severity, frequency = point.get('severity'), point.get('frequency')
            # No inferred conversion or ordinal arithmetic. A missing cell remains unassessed.
            for cell in matrix.get('cells', []) if isinstance(matrix.get('cells'), list) else []:
                if isinstance(cell, dict) and cell.get('severity') == severity and cell.get('frequency') == frequency and severity and frequency:
                    return str(cell.get('category') or 'unassessed')
            return 'unassessed'
        rows.append({'hazard': h['id'], 'title': h['title'], 'severity': h['data'].get('severity', 'unassessed'),
                     'controls': controls, 'requirements': requirements, 'verifications': verifications,
                     'decision': decision.get('outcome', 'pending'), 'decision_needs_review': stale,
                     'initial_risk': risk('initial'), 'residual_risk': risk('residual'), 'gaps': gaps})
    return rows


def csv_register(snap):
    stream = io.StringIO(newline='')
    writer = csv.writer(stream)
    writer.writerow(['project_id', 'project_revision', 'id', 'kind', 'title', 'state', 'revision', 'description', 'data_json'])
    for e in snap['entities']:
        row = [snap['project']['id'], snap['project']['revision'], e['id'], e['kind'], e['title'], e['state'], e['revision'], e['description'], canonical(e['data'])]
        # Formula-safe spreadsheet view; JSON is the lossless exchange.
        writer.writerow(["'"+v if isinstance(v, str) and v.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')) else v for v in row])
    return stream.getvalue()


def sysml_projection(snap):
    """Conservative typed structural/requirements projection; sidecar retains full semantics."""
    lines = ['package RAMSStudy {', '    private import ScalarValues::*;',
             '    part def StudyItem;', f'    doc /* Project {snap["project"]["id"]} revision {snap["project"]["revision"]}. Advisory projection; read project.json. */']
    included, omitted = [], []
    names = {e['id']: 'e_'+e['id'].replace('-', '_')+'_'+digest(e['id'])[:8] for e in snap['entities']}
    children = {}
    for l in snap['links']:
        if l['relation'] == 'contains': children.setdefault(l['source'], []).append(l['target'])
    by_id = {e['id']: e for e in snap['entities']}
    parented = {t for targets in children.values() for t in targets}
    def safe(s): return s.replace('*/', '* /').replace('\x00', '')
    def item(e, indent):
        n = names[e['id']]
        lines.append(' '*indent+f'part {n} : StudyItem {{')
        lines.append(' '*(indent+4)+f'doc /* {safe(e["title"])}; external ID {e["id"]}; record revision {e["revision"]}. */')
        for child in sorted(children.get(e['id'], [])): item(by_id[child], indent+4)
        lines.append(' '*indent+'}')
        included.append(e['id'])
    for e in snap['entities']:
        if e['kind'] == 'item' and e['id'] not in parented: item(e, 4)
        elif e['kind'] == 'requirement':
            lines += [f'    requirement def {names[e["id"]]} {{',
                      f'        doc /* {safe(e["title"])}. {safe(e["description"])}; external ID {e["id"]}; record revision {e["revision"]}. */', '    }']
            included.append(e['id'])
        elif e['kind'] != 'item': omitted.append(e['id'])
    lines.append('}')
    return {'sysml': '\n'.join(lines)+'\n', 'exchange': snap,
            'projection': {'profile': 'rams-structure-requirements/0.1', 'included_ids': sorted(included),
                           'sidecar_only_ids': sorted(omitted), 'relationships_in_sysml': ['contains'],
                           'sidecar_only_relationships': [l for l in snap['links'] if l['relation'] != 'contains'],
                           'limitations': ['Hazard, risk, failure logic, evidence, decisions and units remain in exchange JSON.',
                                           'Requirement prose has no executable constraint; no satisfy or verify assertion is generated.',
                                           'No native RAAML, round-trip SysML import or live tool write-back.',
                                           'Generated names are local symbols; external IDs and record revisions remain in sidecar and documentation.']}}
